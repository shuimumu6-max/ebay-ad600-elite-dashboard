@echo off
chcp 65001 >nul
title 检查更新
"%~dp0bin\node.exe" "%~dp0在线更新.mjs" %*
echo.
pause
