// 「一键补齐」的排队计划：把缺口拆成「一天一步」，逐步串行执行。
// 拆出来单独放，是为了能离线跑测试（不用真去 eBay 下载）。
//
// 约定：
//   1. 流量 / PLP 都按天一步（PLP 走 campaign 页，起止=同一天，一天一份）；
//   2. PLG 只有预设区间（今天/昨天/本周/上周），一份就覆盖整个缺口，单独一步、
//      不按天重复提交（同一天重复提交容易被 eBay 回「We couldn't process your download」）；
//      缺口跨了两周时会拆成多步（上周一步、本周一步），不再因为「没一个预设能盖住」直接报错；
//   3. 步与步之间留 gapSec 秒（默认 90，限 60~120）；
//   4. 归档 / 推看板不在这里，等下载跑完、拿到运行目录后再补到队尾。

export const GAP_MIN_SEC = 60;
export const GAP_MAX_SEC = 120;
export const GAP_DEFAULT_SEC = 90;

export function clampGapSec(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return GAP_DEFAULT_SEC;
  return Math.min(GAP_MAX_SEC, Math.max(GAP_MIN_SEC, Math.round(n)));
}

// PLG 的四个「按日」预设，以及它们覆盖的日期区间（today = 太平洋时间的今天）
export const PLG_PRESETS = ['TODAY', 'YESTERDAY', 'CURRENTWEEK', 'LASTWEEK'];
export function presetRange(preset, today) {
  const d = new Date(`${today}T00:00:00Z`);
  const shift = n => { const x = new Date(d); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
  const monday = shift(-(((d.getUTCDay() + 6) % 7)));
  switch (preset) {
    case 'TODAY': return [today, today];
    case 'YESTERDAY': return [shift(-1), shift(-1)];
    case 'CURRENTWEEK': return [monday, shift(-(((d.getUTCDay() + 6) % 7)) + 6)];
    case 'LASTWEEK': {
      const lastMon = new Date(`${monday}T00:00:00Z`);
      lastMon.setUTCDate(lastMon.getUTCDate() - 7);
      const a = lastMon.toISOString().slice(0, 10);
      const b = new Date(lastMon); b.setUTCDate(b.getUTCDate() + 6);
      return [a, b.toISOString().slice(0, 10)];
    }
    default: return null;
  }
}

// 把缺口按预设分组；超出「上周」的日子返回 unfillable
// （eBay 的按日数据只给到上周，更早的日子选不到，报错也补不了，只能告诉用户）
//
// 匹配顺序是「周 → 天」：一周里缺两天时，用一次「本周」比拆成「昨天 + 本周」少提交一次请求。
// eBay 的广告报表提交次数是珍贵的（连点会被回 We couldn't process your download），
// 少一次就少一次失败机会；「本周」报表同样包含昨天那天的数据。
const PRESET_PRIORITY = ['CURRENTWEEK', 'LASTWEEK', 'YESTERDAY', 'TODAY'];

export function groupPlgByPreset(days = [], today) {
  const groups = [];
  const unfillable = [];
  for (const day of days) {
    const preset = PRESET_PRIORITY.find(p => {
      const r = presetRange(p, today);
      return r && day >= r[0] && day <= r[1];
    });
    if (!preset) { unfillable.push(day); continue; }
    const g = groups.find(x => x.preset === preset);
    if (g) g.days.push(day); else groups.push({ preset, days: [day] });
  }
  for (const g of groups) g.days.sort();
  groups.sort((a, b) => PRESET_PRIORITY.indexOf(a.preset) - PRESET_PRIORITY.indexOf(b.preset));
  return { groups, unfillable: unfillable.sort() };
}

export function planGapFill({ trafficDays = [], plgDays = [], plpDays = [], plgPreset = '', plgGroups = [], outDir, campaigns = [], gapSec = GAP_DEFAULT_SEC } = {}) {
  const trafficSet = new Set(trafficDays);
  const plpSet = new Set(plpDays);
  const allDays = [...new Set([...trafficDays, ...plpDays])].sort();
  const waitMs = clampGapSec(gapSec) * 1000;
  const steps = [];

  for (const day of allDays) {
    const only = [];
    if (trafficSet.has(day)) only.push('trafficDaily');
    if (plpSet.has(day)) only.push('plp');
    if (!only.length) continue;
    const args = ['run-download.mjs', '--out', outDir, '--only', only.join(','), '--max-tabs', '10', '--date', day];
    if (trafficSet.has(day)) args.push('--dates', day);
    if (plpSet.has(day)) {
      args.push(
        '--plp-types', 'listing,keyword,search',
        '--campaigns', campaigns.join(','),
        '--plp-days', day
      );
    }
    steps.push({ day, mode: 'download', args, gapMs: waitMs, kinds: only });
  }

  // PLG：一个预设一步（跨两周就是两步）。老调用方只传 plgDays + plgPreset 也照旧能用
  const groups = plgGroups.length
    ? plgGroups
    : (plgDays.length && plgPreset ? [{ preset: plgPreset, days: plgDays }] : []);
  for (const g of groups) {
    const list = g.days || [];
    if (!list.length) continue;
    steps.push({
      day: `PLG ${g.preset}`,
      title: `PLG 链接广告（${list[0]} ~ ${list[list.length - 1]}，预设 ${g.preset}）`,
      mode: 'download',
      kinds: ['plg'],
      args: ['run-download.mjs', '--out', outDir, '--only', 'plg', '--max-tabs', '10',
        '--date', list[list.length - 1], '--plg-unit', 'DAILY', '--plg-range', g.preset],
      gapMs: waitMs
    });
  }

  return { steps, days: allDays, gapMs: waitMs };
}

// 下一步之前要等多久：下载步骤之间留间隔；归档 / 推看板本身 gapMs=0，跑完立刻接上
export function waitBeforeStep(current, next, fallbackMs = 0) {
  if (!next) return 0;
  if (next.gapMs === 0) return 0;
  if (current && Number.isFinite(current.gapMs)) return current.gapMs;
  return fallbackMs;
}

// 下载跑完后，把「逐个归档 → 推看板」补到队尾（运行目录是跑完才知道的）
export function tailSteps(runDirs = []) {
  const tail = runDirs.map((dir, k) => ({
    day: `归档 ${k + 1}/${runDirs.length}`,
    title: `归档 ${k + 1}/${runDirs.length}（${String(dir).split(/[\\/]/).filter(Boolean).pop()}）`,
    mode: 'publish',
    args: ['archive-publish.mjs', '--run', dir, '--no-publish'],
    gapMs: 0
  }));
  tail.push({ day: '更新看板', title: '更新看板', mode: 'publish', args: ['publish-only.mjs'], gapMs: 0 });
  return tail;
}
