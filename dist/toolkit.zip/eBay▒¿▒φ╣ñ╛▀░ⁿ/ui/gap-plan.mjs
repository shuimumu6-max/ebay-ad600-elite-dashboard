// 「一键补齐」的排队计划：把缺口拆成「一天一步」，逐步串行执行。
// 拆出来单独放，是为了能离线跑测试（不用真去 eBay 下载）。
//
// 约定：
//   1. 流量 / PLP 都按天一步（PLP 走 campaign 页，起止=同一天，一天一份）；
//   2. PLG 只有预设区间（今天/昨天/本周/上周），一份就覆盖整个缺口，单独一步、
//      不按天重复提交（同一天重复提交容易被 eBay 回「We couldn't process your download」）；
//   3. 步与步之间留 gapSec 秒（默认 90，限 60~120）；
//   4. 归档 / 推看板不在这里，等下载跑完、拿到运行目录后再补到队尾。

export const GAP_MIN_SEC = 60;
export const GAP_MAX_SEC = 120;
export const GAP_DEFAULT_SEC = 90;

export function clampGapSec(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return GAP_DEFAULT_SEC;
  return Math.min(GAP_MAX_SEC, Math.max(GAP_MIN_SEC, Math.round(n)));
}

export function planGapFill({ trafficDays = [], plgDays = [], plpDays = [], plgPreset = '', outDir, campaigns = [], gapSec = GAP_DEFAULT_SEC } = {}) {
  const trafficSet = new Set(trafficDays);
  const plpSet = new Set(plpDays);
  const allDays = [...new Set([...trafficDays, ...plpDays])].sort();
  const waitMs = clampGapSec(gapSec) * 1000;
  const steps = [];

  for (const day of allDays) {
    const only = [];
    if (trafficSet.has(day)) only.push('trafficDaily');
    if (plpSet.has(day)) only.push('plp');
    if (!only.length) continue;
    const args = ['run-download.mjs', '--out', outDir, '--only', only.join(','), '--max-tabs', '10', '--date', day];
    if (trafficSet.has(day)) args.push('--dates', day);
    if (plpSet.has(day)) {
      args.push(
        '--plp-types', 'listing,keyword,search',
        '--campaigns', campaigns.join(','),
        '--plp-days', day
      );
    }
    steps.push({ day, mode: 'download', args, gapMs: waitMs, kinds: only });
  }

  if (plgDays.length && plgPreset) {
    steps.push({
      day: `PLG ${plgPreset}`,
      title: `PLG 链接广告（${plgDays[0]} ~ ${plgDays[plgDays.length - 1]}，预设 ${plgPreset}）`,
      mode: 'download',
      kinds: ['plg'],
      args: ['run-download.mjs', '--out', outDir, '--only', 'plg', '--max-tabs', '10',
        '--date', plgDays[plgDays.length - 1], '--plg-unit', 'DAILY', '--plg-range', plgPreset],
      gapMs: waitMs
    });
  }

  return { steps, days: allDays, gapMs: waitMs };
}

// 下一步之前要等多久：下载步骤之间留间隔；归档 / 推看板本身 gapMs=0，跑完立刻接上
export function waitBeforeStep(current, next, fallbackMs = 0) {
  if (!next) return 0;
  if (next.gapMs === 0) return 0;
  if (current && Number.isFinite(current.gapMs)) return current.gapMs;
  return fallbackMs;
}

// 下载跑完后，把「逐个归档 → 推看板」补到队尾（运行目录是跑完才知道的）
export function tailSteps(runDirs = []) {
  const tail = runDirs.map((dir, k) => ({
    day: `归档 ${k + 1}/${runDirs.length}`,
    title: `归档 ${k + 1}/${runDirs.length}（${String(dir).split(/[\\/]/).filter(Boolean).pop()}）`,
    mode: 'publish',
    args: ['archive-publish.mjs', '--run', dir, '--no-publish'],
    gapMs: 0
  }));
  tail.push({ day: '更新看板', title: '更新看板（推 GitHub Pages）', mode: 'publish', args: ['publish-only.mjs'], gapMs: 0 });
  return tail;
}
