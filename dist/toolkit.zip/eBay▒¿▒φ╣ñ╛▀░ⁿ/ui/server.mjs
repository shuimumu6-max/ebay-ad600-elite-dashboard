// eBay 报表控制台：本地网页界面 + 后台调用 download.mjs
// 只监听 127.0.0.1，不对外暴露；职责：环境体检、参数拼装、启动下载、实时日志、结果读取。
import http from 'node:http';
import { spawn } from 'node:child_process';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ensureEnv, bridgeHealth, startBridgeDaemon, openInspectPage, findChrome } from '../app/ensure-env.mjs';
import { yesterdayPacific, monthStart, PLG_CAMPAIGNS, RC_RANGES, ACTIVE_TYPES, ORDER_TYPES, ORDER_RANGES, PRIORITY_TYPES, PRIORITY_CAMPAIGNS, PRIORITY_DEFAULT_IDS } from '../app/config.mjs';
import { dataDirState } from '../app/publish.mjs';
import { scanGaps, pacificToday } from '../app/scan-gaps.mjs';
import { catalogSnapshot } from '../app/reports.mjs';
import { SHOP, shopSummary, configFilePath, saveConfigPatch } from '../app/shop-config.mjs';
import { planGapFill, tailSteps, waitBeforeStep, clampGapSec, GAP_DEFAULT_SEC } from './gap-plan.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const APP_DIR = join(here, '..', 'app');
const NODE = process.execPath;
const PORT = Number(process.env.CONSOLE_PORT || SHOP.consolePort);
let OUT_DIR = process.env.REPORT_OUT_DIR || SHOP.runsDir;
const LOG_FILE = join(here, 'console.log');
const DASHBOARD_URL = process.env.DASHBOARD_URL || SHOP.dashboardUrl;

// 新装（或换机器）时「数据」「下载结果」两个目录还不存在：先建好，
// 否则补缺 / 归档会在 scandir 上抛 ENOENT（已踩过一次）。
for (const dir of [OUT_DIR, SHOP.dataDir]) {
  try { mkdirSync(dir, { recursive: true }); } catch { /* 忽略：真写不进去会在下载时报更明确的错 */ }
}

// 活动列表可在运行中热更新（点「刷新活动列表」跑完自动扫描后不用重启控制台）：
// 空数组 = 报表中心后台默认的全部活动，这是默认状态，完全不需要配置。
let plgList = PLG_CAMPAIGNS;
let priorityList = PRIORITY_CAMPAIGNS;
let priorityDefault = PRIORITY_DEFAULT_IDS;
let shopMeta = { shopName: SHOP.shopName, sellerName: SHOP.sellerName || '' };
// null = 还没扫过；true/false = 下载结果目录里有没有 CSV（决定要不要显示「首次使用」引导）
let runsCsvSeen = null;
let runsCsvCheckedAt = 0;

function readJsonFile(path) {
  try { return JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, '')); } catch { return null; }
}

// 从磁盘重读活动配置：my-shop.json（PLP/PLG + 店铺名）+ app/priority-campaigns.json（活动名池）
function reloadCampaigns() {
  const config = readJsonFile(configFilePath()) || {};
  const normalize = list => (Array.isArray(list) ? list : [])
    .map(c => typeof c === 'string' ? { id: c, name: c } : { id: String(c?.id || ''), name: String(c?.name || c?.id || '') })
    .filter(c => c.id);
  plgList = normalize(config.plgCampaigns);
  const plpIds = (Array.isArray(config.plpCampaigns) ? config.plpCampaigns : []).map(String).filter(Boolean);
  const snapshot = readJsonFile(join(APP_DIR, 'priority-campaigns.json'));
  const owner = String(config.sellerName || shopMeta.sellerName || shopMeta.shopName || '').trim();
  const snapshotOwner = snapshot?.seller || snapshot?.shopName;
  const pool = snapshot && (!snapshotOwner || !owner || snapshotOwner === owner)
    ? normalize(snapshot.campaigns)
        .map(c => ({ ...c, plp: plpIds.includes(c.id) }))
    : plpIds.map(id => ({ id, name: id, plp: true }));
  priorityList = pool;
  priorityDefault = Array.isArray(config.priorityDefaultCampaigns)
    ? config.priorityDefaultCampaigns.map(String)
    : plpIds.filter(id => pool.some(c => c.id === id));
  shopMeta = {
    shopName: String(config.shopName || '').trim() || SHOP.shopName,
    sellerName: String(config.sellerName || shopMeta.sellerName || '').trim()
  };
  return { plgList, priorityList, priorityDefault, shopMeta };
}


// ---------- 运行态 ----------
let child = null;
let scanChild = null;                                // 活动扫描子进程（只读，不影响下载）
let runInfo = null;                                  // { startedAt, args, lines }
// 逐天串行队列：一键补齐全天跑完一天 → 等一会儿 → 再跑下一天（同一天重复提交容易被 eBay 拒）
let seq = null;                                      // { steps, i, gapMs, label, timer }
// 两路并行：流量一路、广告一路（报表中心按「请求行名」排队，PLG 与优先促刊行名相同，
// 这两类并发会互相认领文件，所以广告必须自己串行；流量行名不同，可以和广告同时跑）
let par = null;                                      // { label, queues, runDirs, procs }
let buffer = [];                                     // 最近日志行，供新连接补屏
const clients = new Set();                           // SSE 连接

const j = obj => JSON.stringify(obj);
const say = text => {
  const line = String(text);
  buffer.push(line);
  if (buffer.length > 3000) buffer.shift();
  for (const res of clients) res.write(`data: ${j({ line })}\n\n`);
  try { appendFileSync(LOG_FILE, line + '\n'); } catch { /* 忽略 */ }
};

function broadcast(event, payload) {
  for (const res of clients) res.write(`event: ${event}\ndata: ${j(payload)}\n\n`);
}

// 只读识别店铺名（跑 auto-scan.mjs --seller-only，约 5~10 秒）。成功返回卖家名。
function runSellerScan() {
  return new Promise((resolve, reject) => {
    const proc = spawn(NODE, [join(APP_DIR, 'auto-scan.mjs'), '--seller-only', '--json', '--quiet'], {
      cwd: dirname(APP_DIR), windowsHide: true
    });
    scanChild = proc;
    let out = '';
    proc.stdout.on('data', chunk => { out += String(chunk); });
    proc.stderr.on('data', chunk => { out += String(chunk); });
    const timer = setTimeout(() => {
      try { proc.kill(); } catch { /* 忽略 */ }
      reject(new Error('读取超时：浏览器没有响应，重新打开浏览器再试'));
    }, 60000);
    proc.on('close', () => {
      clearTimeout(timer);
      scanChild = null;
      reloadCampaigns();
      broadcast('shop', { name: shopMeta.shopName, seller: shopMeta.sellerName });
      const line = out.split(/\r?\n/).reverse().find(l => l.startsWith('@@result:'));
      let result = null;
      try { result = line ? JSON.parse(line.slice('@@result:'.length)) : null; } catch { /* 忽略 */ }
      if (result?.ok && result.seller) resolve(result.seller);
      else reject(new Error(result?.error || '没读到卖家名：确认浏览器已登录 eBay 卖家后台'));
    });
  });
}

// ---------- 首次初始化：一次把能拿到的历史数据都下下来，看板一打开就有内容 ----------
// 口径（2026-11-09 实测修正）：eBay 报表中心「按日」粒度只给 今天/昨天/本周/上周，
// 所以**广告数据最多只能按日回溯两周**（上月/自定义必须用 SUMMARY 汇总，没有逐日行）。
// 因此：流量逐日 N 天（能拿满 30 天）；PLG 和优先促刊各下「上周 + 本周」两份按日数据。
function shiftDays(iso, days) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// 返回两路队列：流量·在售 一路，广告 一路（广告内部必须串行：PLG 与优先促刊行名相同）
function firstRunPlan(days = 30) {
  const end = yesterdayPacific();
  const start = shiftDays(end, -(days - 1));
  const base = ['run-download.mjs', '--out', OUT_DIR, '--max-tabs', '10'];
  const traffic = {
    day: `Traffic ${start}~${end}`,
    title: `流量报表（${start} ~ ${end}，逐日 ${days} 份）`,
    args: [...base, '--only', 'traffic', '--dates', `${start}..${end}`, '--date', end]
  };
  const active = {
    day: '在售名单',
    title: '在售商品名单（1 份，用于产品/机型归属）',
    args: [...base, '--only', 'active', '--date', end, '--active-type', 'active']
  };
  const plgLast = {
    day: 'PLG 上周',
    title: 'PLG 链接广告（上周，按日）',
    args: [...base, '--only', 'plg', '--date', end, '--plg-unit', 'DAILY', '--plg-range', 'LASTWEEK']
  };
  const plgThis = {
    day: 'PLG 本周',
    title: 'PLG 链接广告（本周，按日）',
    args: [...base, '--only', 'plg', '--date', end, '--plg-unit', 'DAILY', '--plg-range', 'CURRENTWEEK']
  };
  const prLast = {
    day: '优先促刊 上周',
    title: '优先促销刊登（上周，按日：物品刊登 / 关键词 / 活动 / 搜索词）',
    args: [...base, '--only', 'priority', '--date', end,
      '--priority-types', 'listing,keyword,campaign,search',
      '--priority-unit', 'DAILY', '--priority-range', 'LASTWEEK']
  };
  const prThis = {
    day: '优先促刊 本周',
    title: '优先促销刊登（本周，按日：物品刊登 / 关键词 / 活动 / 搜索词）',
    args: [...base, '--only', 'priority', '--date', end,
      '--priority-types', 'listing,keyword,campaign,search',
      '--priority-unit', 'DAILY', '--priority-range', 'CURRENTWEEK']
  };
  const queues = [
    { label: '流量', steps: [traffic, active] },
    { label: '广告', steps: [plgLast, plgThis, prLast, prThis] }
  ];
  const steps = queues.flatMap(q => q.steps);
  return { steps, queues, start, end, days };
}

// 下载结果目录里有没有 CSV：新用户装完第一次打开时用来判断「要不要引导初始化」
function runsCsvCount() {
  let count = 0;
  const walk = dir => {
    if (count > 500) return;
    let entries = [];
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      if (entry.isDirectory()) walk(join(dir, entry.name));
      else if (entry.name.toLowerCase().endsWith('.csv')) count++;
    }
  };
  if (existsSync(OUT_DIR)) walk(OUT_DIR);
  return count;
}

// ---------- 环境体检 ----------
// 只问常驻桥（毫秒级），不再每次做 8 秒的 WS 握手探测；
// 桥不在就顺手拉起守护，用户不用关心进程在不在。
let lastDaemonTry = 0;
async function envState() {
  let h = await bridgeHealth();
  if (!h && Date.now() - lastDaemonTry > 10000) {
    lastDaemonTry = Date.now();
    startBridgeDaemon();
  }
  // 有没有下载过 CSV：15 秒最多扫一次目录，避免每次轮询都遍历几千个文件
  if (runsCsvSeen === null || (!runsCsvSeen && Date.now() - runsCsvCheckedAt > 15000)) {
    runsCsvSeen = runsCsvCount() > 0;
    runsCsvCheckedAt = Date.now();
  }
  const connected = !!h?.connected;
  return {
    chrome: {
      ok: connected,
      browser: connected ? 'Chrome（常驻连接已在线）' : null,
      reason: connected ? null : (h?.hint || '常驻桥未启动')
    },
    bridge: {
      ok: connected,
      online: !!h,
      phase: h?.phase || (h ? 'reconnecting' : 'offline'),
      needsAuth: !!h?.needsAuth,
      uptimeSec: h?.uptimeSec || 0,
      reconnectTries: h?.reconnectTries || 0,
      hint: h?.hint || '常驻桥未启动'
    },
    running: !!child || !!seq || !!par,
    mode: runInfo?.mode || null,
    runStartedAt: runInfo?.startedAt || null,
    outDir: OUT_DIR,
    dashboard: DASHBOARD_URL,
    dataState: dataDirState(),
    // 新用户第一次打开：下载结果目录里还没有任何 CSV，就在页面上引导「自动下载最近 30 天」
    firstRun: { needed: !runsCsvSeen, days: 30, outDir: OUT_DIR },
    shop: {
      name: shopMeta.shopName,
      seller: shopMeta.sellerName,
      // 还没识别出店铺名（新装用户）——界面会提示「点一下自动识别」
      placeholder: !shopMeta.shopName || shopMeta.shopName === '我的店铺',
      configFile: configFilePath(),
      // 0 个活动不是错：代表「报表中心后台默认全部活动」，也是最省事的默认状态
      plgCount: plgList.length,
      priorityCount: priorityList.length,
      campaignsMode: (plgList.length || priorityList.length) ? '指定活动' : '后台全部活动'
    },
    defaults: defaultForm(),
    last: lastSummary()
  };
}

function defaultForm() {
  const date = yesterdayPacific();
  return {
    date,
    rangeStart: monthStart(date),
    rangeEnd: date,
    // 空数组不是「没选」：空 = 报表中心后台默认的全部活动，下载侧不传活动参数
    plgCampaigns: plgList.map(c => c.id),
    plgCampaignList: plgList,
    ranges: RC_RANGES,
    activeTypes: Object.entries(ACTIVE_TYPES).map(([key, v]) => ({ key, label: v.label })),
    orderTypes: ORDER_TYPES.map(t => ({ key: t.key, label: t.label, mvp: t.mvp })),
    orderRanges: ORDER_RANGES,
    priorityTypes: PRIORITY_TYPES.map(t => ({ key: t.key, label: t.label, mvp: t.mvp })),
    priorityCampaignList: priorityList,
    priorityDefaultCampaigns: priorityDefault,
    outDir: OUT_DIR
  };
}

function runDirsNewestFirst() {
  if (!existsSync(OUT_DIR)) return [];
  return readdirSync(OUT_DIR)
    .filter(name => /^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$/.test(name))
    .map(name => ({ name, at: statSync(join(OUT_DIR, name)).mtimeMs }))
    .sort((a, b) => b.at - a.at)
    .map(item => join(OUT_DIR, item.name));
}

function newestRunDir() {
  return runDirsNewestFirst()[0] || null;
}

function readSummary(dir) {
  const file = join(dir, '结果.json');
  if (!existsSync(file)) return null;
  try {
    const s = JSON.parse(readFileSync(file, 'utf8'));
    return {
      runDir: dir,
      runId: s.runId,
      totalMs: s.totalMs,
      date: s.date,
      rangeStart: s.rangeStart,
      plpStart: s.plpStart,
      plpEnd: s.plpEnd,
      counts: s.counts,
      warnings: s.warnings || [],
      errors: s.errors || [],
      files: (s.files || []).map(f => ({
        name: f.name, kind: f.kind, label: f.label, task: f.task,
        rowCount: f.rowCount, size: f.size, valid: f.valid, problem: f.problem || null,
        folder: (f.path || '').split(/[\\/]/).slice(-2, -1)[0] || ''
      }))
    };
  } catch { return null; }
}

// 只认本次：控制台这次启动后跑出来的结果。服务重开就是空白，不再回退历史目录，
// 免得把上一次的旧文件当成这次的产出。
function lastSummary() {
  if (!runInfo?.runDir) return null;
  return readSummary(runInfo.runDir);
}

// 最近的运行目录（带 结果.json 的），给「补做归档 + 更新看板」下拉框用
function recentRuns(limit = 20) {
  if (!existsSync(OUT_DIR)) return [];
  const out = [];
  for (const entry of readdirSync(OUT_DIR, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const dir = join(OUT_DIR, entry.name);
    const file = join(dir, '结果.json');
    if (!existsSync(file)) continue;
    try {
      const s = JSON.parse(readFileSync(file, 'utf8'));
      const files = (s.files || []).filter(f => f && f.path && f.valid !== false && !f.problem);
      out.push({
        name: entry.name, dir,
        startedAt: s.startedAt || '',
        only: Array.isArray(s.only) ? s.only : [],
        total: (s.counts?.total ?? (s.files || []).length),
        valid: (s.counts?.valid ?? files.length),
        archived: !!s.apply,
        published: !!s.publish,
        filesReady: files.filter(f => existsSync(f.path)).length
      });
    } catch { /* 坏的 结果.json 跳过 */ }
  }
  return out.sort((a, b) => (a.name < b.name ? 1 : -1)).slice(0, limit);
}

// ---------- 参数拼装 ----------
function buildArgs(form) {
  const out = String(form.outDir || '').trim();
  if (out && !isAbsolute(out)) throw new Error('结果目录要填 Windows 绝对路径');
  if (out.includes('..')) throw new Error('结果目录不能包含 ..');
  const args = ['run-download.mjs', '--out', out || OUT_DIR];
  const only = [];
  const tm = form.trafficMode || 'daily';
  if (tm === 'daily') only.push('trafficDaily');
  if (tm === 'range') only.push('trafficRange');
  if (tm === 'both') only.push('traffic');
  if (tm === 'batch') only.push('trafficDaily');
  if (form.plg) only.push('plg');
  if (form.active) only.push('active');
  if (form.orders) only.push('orders');
  if (form.priority) only.push('priority');
  if (!only.length) throw new Error('至少要选一份报表');

  args.push('--only', only.join(','));
  const maxTabs = Number(form.maxTabs || 4);
  if (Number.isFinite(maxTabs) && maxTabs >= 1 && maxTabs <= 10) args.push('--max-tabs', String(Math.round(maxTabs)));
  args.push('--date', form.date || yesterdayPacific());
  if (tm === 'batch') {
    const dates = String(form.batchDates || '').trim();
    if (!dates) throw new Error('批量模式需要填日期，如 2026-11-01..2026-11-05');
    args.push('--dates', dates);
  }
  if (tm === 'range' || tm === 'both') {
    args.push('--range-start', form.rangeStart);
    if (form.rangeEnd) args.push('--range-end', form.rangeEnd);
  }

  if (form.plg) {
    args.push('--plg-unit', form.plgUnit || 'DAILY');
    if (form.plgRange) args.push('--plg-range', form.plgRange);
    if (form.plgRange === 'CUSTOM') {
      if (!form.plgCustomStart || !form.plgCustomEnd) throw new Error('自定义区间要填起止日期');
      if (form.plgCustomStart > form.plgCustomEnd) throw new Error('自定义区间起始日晚于结束日');
      args.push('--plg-custom-start', form.plgCustomStart, '--plg-custom-end', form.plgCustomEnd);
    }
    // 活动列表：空 = 不传参数 = 报表中心后台默认的全部活动（推荐路径，运营不用管）。
    // 只有明确挑了「一部分活动」才传，用来缩小报表范围。
    const plgPicked = (form.plgCampaigns || []).filter(Boolean);
    if (plgPicked.length && plgList.length && plgPicked.length < plgList.length) {
      args.push('--plg-campaigns', plgPicked.join(','));
    }
  }
  if (form.active) args.push('--active-type', form.activeType || 'active');

  if (form.orders) {
    args.push('--order-type', form.orderType || 'all');
    args.push('--order-range', form.orderRange || 'LAST90D');
    if (form.orderRange === 'CUSTOM') {
      if (!form.orderCustomStart || !form.orderCustomEnd) throw new Error('订单自定义区间要填起止日期');
      if (form.orderCustomStart > form.orderCustomEnd) throw new Error('订单区间起始日晚于结束日');
      args.push('--order-custom-start', form.orderCustomStart, '--order-custom-end', form.orderCustomEnd);
    }
  }

  if (form.priority) {
    const ptypes = (form.priorityTypes || []).filter(Boolean);
    if (!ptypes.length) throw new Error('优先促销刊登至少要选一种报表类型');
    const bad = ptypes.filter(k => !PRIORITY_TYPES.some(t => t.key === k));
    if (bad.length) throw new Error(`优先促销刊登类型不支持：${bad.join(',')}`);
    args.push('--priority-types', ptypes.join(','));
    args.push('--priority-unit', form.priorityUnit || 'DAILY');
    if (form.priorityRange) args.push('--priority-range', form.priorityRange);
    if (form.priorityRange === 'CUSTOM') {
      if (!form.priorityCustomStart || !form.priorityCustomEnd) throw new Error('优先促刊自定义区间要填起止日期');
      if (form.priorityCustomStart > form.priorityCustomEnd) throw new Error('优先促刊区间起始日晚于结束日');
      args.push('--priority-custom-start', form.priorityCustomStart, '--priority-custom-end', form.priorityCustomEnd);
    }
    const pc = (form.priorityCampaigns || []).filter(Boolean);
    const known = new Set(priorityList.map(c => c.id));
    const unknown = pc.filter(id => !known.has(id));
    if (unknown.length) throw new Error(`优先促销刊登活动不在列表里：${unknown.join(',')}`);
    if (pc.length && pc.length < priorityList.length) args.push('--priority-campaigns', pc.join(','));
    else if (priorityList.length && pc.length === priorityList.length) args.push('--priority-campaigns', 'all');
  }
  if (form.keepTabs) args.push('--keep');
  if (form.publish) args.push('--publish');
  else if (form.apply) args.push('--apply');
  return args;
}

// ---------- 一键补齐：扫描缺口 → 组参 → 下载 → 自动归档 + 更新看板 ----------
const dayList = (s, e) => {
  const out = [];
  for (let t = Date.parse(`${s}T00:00:00Z`); t <= Date.parse(`${e}T00:00:00Z`); t += 86400000) {
    out.push(new Date(t).toISOString().slice(0, 10));
  }
  return out;
};
// 报表中心「按日」粒度只给四个预设（实测 2026-11-08）：挑能整体盖住缺口的最小那个
function presetFor(days) {
  if (!days.length) return null;
  const fmt = x => x.toISOString().slice(0, 10);
  const shift = (x, n) => { const y = new Date(x); y.setUTCDate(y.getUTCDate() + n); return y; };
  const t0 = new Date(`${pacificToday()}T00:00:00Z`);
  const w0 = shift(t0, -(((t0.getUTCDay() + 6) % 7)));
  const presets = [
    ['TODAY', fmt(t0), fmt(t0)],
    ['YESTERDAY', fmt(shift(t0, -1)), fmt(shift(t0, -1))],
    ['CURRENTWEEK', fmt(w0), fmt(shift(w0, 6))],
    ['LASTWEEK', fmt(shift(w0, -7)), fmt(shift(w0, -1))]
  ];
  const lo = days[0];
  const hi = days[days.length - 1];
  const hit = presets.find(([, a, b]) => lo >= a && hi <= b);
  return hit ? hit[0] : null;
}

// 统一启动后台任务：下载（download.mjs）与只更新看板（publish-only.mjs）共用日志流
function startJob(args, mode, label, onExit) {
  buffer = [];
  runInfo = { startedAt: Date.now(), args, runDir: null, mode };
  say(`[控制台] ${label}：${[NODE, ...args].join(' ')}`);
  broadcast('run', { phase: 'start', args, mode });

  child = spawn(NODE, args, { cwd: APP_DIR, windowsHide: true });
  let tail = '';
  const onData = chunk => {
    tail += chunk.toString('utf8');
    const parts = tail.split(/\r?\n/);
    tail = parts.pop() ?? '';
    for (const line of parts) {
      if (!line.trim()) continue;
      say(line);
      const m = /结果目录：(.*)$/.exec(line);
      if (m && runInfo) runInfo.runDir = m[1].trim();
    }
  };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);
  child.on('exit', code => {
    if (tail.trim()) say(tail.trim());
    // 只认本次自己报出来的结果目录；失败没报就是没有，不去抓历史目录充数
    const dir = runInfo?.runDir || null;
    if (runInfo) runInfo.runDir = dir;
    say(`[控制台] ${mode === 'publish' ? '看板更新' : mode === 'seller' ? '店铺识别' : '下载'}结束，退出码 ${code}`);
    const summary = mode === 'publish' ? null : lastSummary();
    child = null;
    const queueMore = !!seq && (seq.i + 1 < seq.total || seq.thenArchive);
    broadcast('run', {
      phase: 'end', code, mode, summary, dashboard: DASHBOARD_URL,
      dataState: dataDirState(),
      queue: seq ? { index: seq.i + 1, total: seq.total, more: queueMore } : null
    });
    if (onExit) onExit(code);
  });
}

// 逐天串行：每一天跑完等 gapMs，再跑下一天；中间的空档也算「运行中」
// opts.thenArchive：所有下载步骤跑完后，自动补「逐个归档 → 推看板」
function startSequence(steps, label, gapMs, opts = {}) {
  if (!steps.length) return;
  seq = {
    steps, i: 0, gapMs, label, timer: null, total: steps.length,
    runDirs: [], failures: [], thenArchive: !!opts.thenArchive
  };
  say(`[控制台] ${label}：共 ${steps.length} 步，逐天串行，每天之间停 ${Math.round(gapMs / 1000)} 秒`);
  runSeqStep();
}

function runSeqStep() {
  if (!seq) return;
  const step = seq.steps[seq.i];
  const tag = step.title || `第 ${seq.i + 1}/${seq.total} 天（${step.day}）`;
  startJob(step.args, step.mode, `${seq.label} · ${tag}`, code => {
    if (!seq) return;                       // 已被手动停止
    // 店铺识别步骤：把新读到的卖家名 / 活动列表刷进界面（失败不拦后面的下载）
    if (step.mode === 'seller') {
      reloadCampaigns();
      broadcast('shop', { name: shopMeta.shopName, seller: shopMeta.sellerName });
      if (code === 0) say(`[控制台] 店铺已识别：${shopMeta.shopName}`);
    }
    if (step.mode === 'download') {
      const dir = runInfo?.runDir || null;
      if (dir) seq.runDirs.push(dir);
      if (code !== 0) seq.failures.push(`${step.day}（退出码 ${code}）`);
    }
    seq.i++;

    // 下载都跑完了：把「逐个归档 + 推看板」的步骤补到队尾（运行目录要跑完才知道）
    if (seq.i >= seq.total && seq.thenArchive) {
      seq.thenArchive = false;
      const tail = tailSteps(seq.runDirs);
      seq.steps.push(...tail);
      seq.total = seq.steps.length;
      if (!seq.runDirs.length) say('[控制台] 这次没有任何下载成功，直接更新看板');
    }

    if (seq.i >= seq.total) {
      const fails = seq.failures;
      say(`[控制台] ${seq.label} 全部结束：共 ${seq.total} 步`
        + (fails.length ? `，失败 ${fails.length} 步：${fails.join('、')}` : '，全部成功'));
      seq = null;
      return;
    }

    // 等一下步：下载步骤之间要留间隔；归档 / 推看板不用等，跑完立刻接上
    const next = seq.steps[seq.i];
    const waitMs = waitBeforeStep(step, next, seq.gapMs);
    if (waitMs >= 1000) {
      say(`[控制台] ${tag} 结束，等 ${Math.round(waitMs / 1000)} 秒再跑下一步（${next.title || next.day}）…`);
      broadcast('run', { phase: 'gap', waitMs, next: next.title || next.day, index: seq.i + 1, total: seq.total });
      seq.timer = setTimeout(() => { if (seq) { seq.timer = null; runSeqStep(); } }, waitMs);
    } else {
      runSeqStep();
    }
  });
}

function stopSequence() {
  if (!seq) return false;
  if (seq.timer) clearTimeout(seq.timer);
  seq = null;
  return true;
}

// ---------- 两路并行（首次初始化用） ----------
// 收益：30 天的流量报表是最慢的一段（逐日 30 份、串行提交），把广告那几份放到另一路同时跑，
// 总时长就从「流量 + 广告」降到「流量」。
function startParallel(label, queues) {
  buffer = [];
  runInfo = { startedAt: Date.now(), args: [], runDir: null, mode: 'parallel' };
  par = {
    label, startedAt: Date.now(), runDirs: [], procs: new Set(),
    queues: queues.map(q => ({ label: q.label, steps: q.steps, i: 0, running: false, failures: [] }))
  };
  say(`[控制台] ${label}：${queues.length} 路并行（${queues.map(q => q.label).join(' / ')}）；同一路内部仍然串行，避免报表中心认错文件`);
  broadcast('run', { phase: 'start', mode: 'parallel' });
  pumpParallel();
}

function pumpParallel() {
  if (!par) return;
  for (const q of par.queues) {
    if (!q.running && q.i < q.steps.length) spawnQueueStep(q);
  }
  if (par.queues.every(q => !q.running && q.i >= q.steps.length)) finishParallel();
}

function spawnQueueStep(q) {
  const step = q.steps[q.i];
  q.running = true;
  say(`[控制台] [${q.label}] 开始：${step.title || step.day}`);
  const proc = spawn(NODE, step.args, {
    cwd: APP_DIR,
    windowsHide: true,
    // 并行时两路共用同一个浏览器窗口，谁都不许清「历史 /sh 页」，否则会把另一路的页面关掉
    env: { ...process.env, EBAY_KEEP_TABS: '1' }
  });
  par.procs.add(proc);
  let tail = '';
  const onData = chunk => {
    tail += chunk.toString('utf8');
    const parts = tail.split(/\r?\n/);
    tail = parts.pop() ?? '';
    for (const line of parts) {
      if (!line.trim()) continue;
      say(`[${q.label}] ${line}`);
      const m = /结果目录：(.*)$/.exec(line);
      if (m && par) par.runDirs.push(m[1].trim());
    }
  };
  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);
  proc.on('exit', code => {
    if (tail.trim()) say(`[${q.label}] ${tail.trim()}`);
    par?.procs.delete(proc);
    q.running = false;
    if (code !== 0) q.failures.push(`${step.title || step.day}（退出码 ${code}）`);
    q.i++;
    pumpParallel();
  });
}

function finishParallel() {
  if (!par) return;
  const { label, queues, runDirs, startedAt } = par;
  const fails = queues.flatMap(q => q.failures);
  const mins = Math.round((Date.now() - startedAt) / 60000 * 10) / 10;
  say(`[控制台] ${label} 全部结束：用时 ${mins} 分钟，得到 ${runDirs.length} 个结果目录`
    + (fails.length ? `，失败 ${fails.length} 步：${fails.join('、')}` : '，全部成功'));
  par = null;
  runInfo = null;
  broadcast('run', { phase: 'end', code: fails.length ? 1 : 0, mode: 'parallel', summary: lastSummary(), dashboard: DASHBOARD_URL, dataState: dataDirState() });
}

function stopParallel() {
  if (!par) return false;
  for (const proc of par.procs) { try { proc.kill(); } catch { /* 忽略 */ } }
  par = null;
  runInfo = null;
  return true;
}

// ---------- HTTP ----------
function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' ? body : j(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 1e6) reject(new Error('请求过大')); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('请求不是合法 JSON')); } });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const path = url.pathname;

  try {
    if (path === '/' || path === '/index.html') {
      const file = join(here, 'index.html');
      return send(res, 200, readFileSync(file, 'utf8'), 'text/html; charset=utf-8');
    }
    if (path === '/api/state') return send(res, 200, await envState());

    // 改店铺名：名字只是个标签，界面上随手改，写回 my-shop.json
    if (path === '/api/shop-name' && req.method === 'POST') {
      const body = await readBody(req);
      const name = String(body.name || '').trim().slice(0, 40);
      try {
        const saved = saveConfigPatch({ shopName: name });
        shopMeta.shopName = name || SHOP.shopName;
        broadcast('shop', { name: shopMeta.shopName });
        say(`[控制台] 店铺名已改为「${shopMeta.shopName}」（写入 ${saved}）`);
        return send(res, 200, { ok: true, name: shopMeta.shopName, file: saved });
      } catch (error) {
        return send(res, 500, { ok: false, error: `保存失败：${error.message}` });
      }
    }

    // 识别店铺名：只读浏览器里的卖家账号，几秒完成，不碰活动列表、不下载。
    // 新装用户第一次点「识别 / 改名」就走这里，不需要手填店铺名。
    if (path === '/api/detect-shop' && req.method === 'POST') {
      if (child || seq || scanChild || par) return send(res, 409, { ok: false, error: '有任务在跑，等它结束再识别' });
      const state = await bridgeHealth().catch(() => null);
      if (!state?.connected) {
        return send(res, 200, { ok: false, error: '浏览器还没连上：先点页面顶部的「去开开关」，再点一次识别' });
      }
      try {
        const name = await runSellerScan();
        say(`[控制台] 店铺已识别：${name}`);
        return send(res, 200, { ok: true, name, seller: shopMeta.sellerName });
      } catch (error) {
        return send(res, 200, { ok: false, error: error.message });
      }
    }

    // 刷新活动列表（可选功能）：只读扫描报表中心的 Campaigns 卡片，把活动名填进下拉框。
    // 不点也完全能用——活动留空就是「后台默认全部活动」。
    if (path === '/api/auto-scan' && req.method === 'POST') {
      if (scanChild || child || seq || par) return send(res, 409, { ok: false, error: '有任务在跑，等它结束再刷新活动列表' });
      say('[控制台] 开始扫描报表中心的活动列表（只读，不提交任何下载）…');
      const proc = spawn(NODE, [join(APP_DIR, 'auto-scan.mjs'), '--json'], { cwd: dirname(APP_DIR), windowsHide: true });
      scanChild = proc;
      let out = '';
      const onData = chunk => {
        const text = String(chunk);
        out += text;
        for (const line of text.split(/\r?\n/)) {
          if (!line.trim() || line.startsWith('@@')) continue;
          say(line);
        }
      };
      proc.stdout.on('data', onData);
      proc.stderr.on('data', onData);
      proc.on('close', code => {
        scanChild = null;
        const lists = reloadCampaigns();
        const payload = { ok: code === 0, ...lists };
        const resultLine = out.split(/\r?\n/).reverse().find(l => l.startsWith('@@result:'));
        if (resultLine) {
          try { payload.result = JSON.parse(resultLine.slice('@@result:'.length)); } catch { /* 忽略 */ }
        }
        say(code === 0
          ? `[控制台] 活动列表已刷新：PLG ${lists.plgList.length} 个 / 优先促刊 ${lists.priorityList.length} 个`
          : '[控制台] 活动扫描没成功，不影响使用：留空就是后台全部活动，直接下载即可');
        broadcast('scan-done', payload);
        broadcast('shop', { name: shopMeta.shopName });
      });
      return send(res, 200, { ok: true, started: true });
    }

    // 需要授权时：拉起守护 + 在浏览器里打开开关页面，用户拨一次即可
    if (path === '/api/fix-env' && req.method === 'POST') {
      if (!findChrome()) return send(res, 500, { ok: false, error: '没找到 Chrome 安装路径' });
      startBridgeDaemon();
      const opened = openInspectPage();
      say(opened
        ? '[控制台] 已打开 chrome://inspect 开关页面：把 Allow remote debugging 拨到开，之后就不用再管了'
        : '[控制台] 请在浏览器地址栏打开 chrome://inspect/#remote-debugging 并拨开开关');
      return send(res, 200, { ok: opened, needsAuth: true });
    }

    if (path === '/api/preview' && req.method === 'POST') {
      const form = await readBody(req);
      try { return send(res, 200, { ok: true, command: [NODE, ...buildArgs(form)].join(' ') }); }
      catch (error) { return send(res, 200, { ok: false, error: error.message }); }
    }

    if (path === '/api/logs') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-store',
        Connection: 'keep-alive'
      });
      res.write('retry: 2000\n\n');
      res.write(`event: snapshot\ndata: ${j({ lines: buffer.slice(-400) })}\n\n`);
      clients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => { clearInterval(ping); clients.delete(res); });
      return;
    }

    // 首次初始化：一键下载最近 30 天（Traffic 逐日 + PLG 本月/上月 + 优先促刊 4 类 + 在售名单）。
    // 目的是让新装的人打开看板就有数据，不用先研究「该下哪些报表、什么粒度」。
    if (path === '/api/first-run' && req.method === 'POST') {
      if (child || seq || scanChild || par) return send(res, 409, { ok: false, error: '已有任务在跑，先等它结束' });
      const body = await readBody(req).catch(() => ({}));
      const days = Math.min(90, Math.max(7, Number(body.days) || 30));
      const plan = firstRunPlan(days);
      if (body.dryRun) {
        return send(res, 200, {
          ok: true, dryRun: true, start: plan.start, end: plan.end,
          queues: plan.queues.map(q => ({ label: q.label, steps: q.steps.map(s => ({ day: s.day, title: s.title })) })),
          steps: plan.steps.map(s => ({ day: s.day, title: s.title, args: s.args }))
        });
      }
      // 第 1 步永远是「跟店铺后台连上」：连不上就直接说，不要让人等半小时才发现
      const state = await bridgeHealth().catch(() => null);
      if (!state?.connected) {
        return send(res, 200, {
          ok: false,
          error: '浏览器还没连上：先点页面顶部的「去开开关」，把 Allow remote debugging 拨开，再点下载'
        });
      }
      say(`[控制台] 首次初始化：流量 ${days} 天 + 广告（本周/上周）；全程只读下载，不改动任何已有数据`);
      // 先把店铺名读出来（只读，几秒），读不到也不拦着下载
      try { await runSellerScan(); } catch (error) { say(`[控制台] 店铺名没读到（不影响下载）：${error.message}`); }
      // 一步一步来：实测两路并行时，两个进程抢同一个浏览器窗口和同一个下载目录，
      // 流量那一摞会大量失败（7 天只拿到 3 天）——宁可控场慢一点，也不要下不全。
      startSequence(plan.steps.map(step => ({ ...step, mode: 'download' })), `首次初始化（${plan.start} ~ ${plan.end}）`, 0);
      return send(res, 200, {
        ok: true, started: true, start: plan.start, end: plan.end, days,
        queues: plan.queues.map(q => ({ label: q.label, steps: q.steps.map(s => ({ day: s.day, title: s.title })) }))
      });
    }

    // 一键补齐：扫描正式目录的缺口 → 只下载缺的那些 → 归档 → 更新看板
    // 口径（2026-11-08 定）：看板日更 = 流量单日 + PLG 链接广告 + PLP 链接广告（走 campaign 页）
    if (path === '/api/gap-fill' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '已有任务在跑，先等它结束' });
      let scanned;
      try { scanned = await scanGaps({ dashboardUrl: DASHBOARD_URL }); }
      catch (error) { return send(res, 500, { ok: false, error: `扫描失败：${error.message}` }); }
      const byKey = Object.fromEntries(scanned.rows.map(r => [r.key, r]));
      const daysOf = key => (byKey[key]?.missingRanges || []).flatMap(r => dayList(r.start, r.end));
      const trafficDays = daysOf('trafficDaily');
      const plgDays = daysOf('plg');
      // PLP 走 campaign 页通道，必须知道具体活动；活动留空（= 后台全部）时这一路补不了，
      // 直接跳过 PLP、只补流量和 PLG，不让用户卡在一个他没法填的配置项上。
      const plpDaysRaw = [...new Set([...daysOf('plpListing'), ...daysOf('plpKeyword'), ...daysOf('plpSearch')])].sort();
      const plpDays = priorityDefault.length ? plpDaysRaw : [];
      if (!priorityDefault.length && plpDaysRaw.length) {
        say(`[控制台] 跳过 PLP 补齐：当前没指定活动（${plpDaysRaw.length} 天缺口）。PLP 报表需要具体活动，需要补就在「优先促刊」里勾几个活动。`);
      }

      if (!trafficDays.length && !plgDays.length && !plpDays.length) {
        return send(res, 200, { ok: true, started: false, message: '没有缺口，直接更新看板就行' });
      }
      const plgPreset = plgDays.length ? presetFor(plgDays) : null;
      if (plgDays.length && !plgPreset) {
        return send(res, 422, {
          ok: false,
          error: `PLG 缺口 ${plgDays[0]} ~ ${plgDays[plgDays.length - 1]} 超出「按日」粒度可选范围`
            + `（今天 / 昨天 / 本周 / 上周），eBay 选不到就只能等或手动处理`
        });
      }

      const allDays = [...new Set([...trafficDays, ...plpDays])].sort();
      // 每天之间停 1~2 分钟（默认 90 秒）：同一天/相邻天连续提交容易被 eBay 回「We couldn't process your download」
      const form = await readBody(req).catch(() => ({}));
      const gapSec = clampGapSec(form.gapSec);
      const { steps } = planGapFill({
        trafficDays, plgDays, plpDays, plgPreset,
        outDir: OUT_DIR, campaigns: priorityDefault, gapSec
      });
      startSequence(steps, '一键补齐缺口', gapSec * 1000, { thenArchive: true });
      return send(res, 200, {
        ok: true, started: true, gapSec,
        days: allDays,
        steps: steps.map(s => ({ day: s.day, args: s.args })),
        plan: {
          trafficDays, plgDays, plgPreset, plpDays,
          plpRange: plpDays.length ? [plpDays[0], plpDays[plpDays.length - 1]] : null
        }
      });
    }

    if (path === '/api/run' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '已经有一次下载在跑，先停止或等它结束' });
      const form = await readBody(req);
      let args;
      try { args = buildArgs(form); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
      const customOut = String(form.outDir || '').trim();
      if (customOut) OUT_DIR = customOut;
      startJob(args, 'download', '开始下载');
      return send(res, 200, { ok: true, args });
    }

    // 只更新看板：拿正式目录里已归档的数据重新生成 data.js 并推送 GitHub Pages
    if (path === '/api/publish' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '正在跑别的任务，等它结束再更新看板' });
      startJob(['publish-only.mjs'], 'publish', '只更新看板（不下载）');
      return send(res, 200, { ok: true });
    }

    // 最近几次运行：给「补做归档 + 更新看板」用
    if (path === '/api/runs') return send(res, 200, { ok: true, runs: recentRuns() });

    // 对已完成的运行补做「归档 + 更新看板」：不重新下载，直接按 结果.json 归档再推看板
    if (path === '/api/archive-publish' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '正在跑别的任务，等它结束再归档' });
      const form = await readBody(req);
      const runDir = String(form.runDir || '').trim();
      if (runDir && !isAbsolute(runDir)) return send(res, 400, { ok: false, error: '运行目录要填绝对路径' });
      const args = ['archive-publish.mjs'];
      if (runDir) args.push('--run', runDir);
      const tag = runDir ? runDir.split(/[\\/]/).filter(Boolean).pop() : '最近一次运行';
      startJob(args, 'publish', `归档 + 更新看板（${tag}）`);
      return send(res, 200, { ok: true });
    }

    if (path === '/api/data-state') return send(res, 200, { ok: true, state: dataDirState(), dashboard: DASHBOARD_URL });

    // 报表注册表 + 字段字典：控制台「字段」页用，静态数据，直接从 reports.mjs 读
    if (path === '/api/catalog') return send(res, 200, { ok: true, ...catalogSnapshot() });

    // 看板数据体检：正式目录里每类报表哪天有、哪天缺（今天与上架前不算缺）
    if (path === '/api/scan') {
      const report = await scanGaps({ dashboardUrl: `${DASHBOARD_URL}data.js` });
      say(`[控制台] 体检完成：${report.rows.length} 类报表，共缺 ${report.totalMissing} 天`);
      return send(res, 200, report);
    }

    if (path === '/api/stop' && req.method === 'POST') {
      const hadSeq = stopSequence();
      const hadPar = stopParallel();
      if (!child) {
        if (hadSeq) say('[控制台] 已停止逐天补齐队列（等待中的下一步不再执行）');
        if (hadPar) say('[控制台] 已停止两路并行下载（流量 / 广告都停了）');
        return send(res, 200, { ok: true, stopped: hadSeq || hadPar });
      }
      child.kill();
      say(hadSeq
        ? '[控制台] 已请求停止当前下载，逐天队列一并取消'
        : '[控制台] 已请求停止当前下载');
      return send(res, 200, { ok: true, stopped: true });
    }

    if (path === '/api/last') return send(res, 200, { ok: true, summary: lastSummary() });

    if (path === '/api/open' && req.method === 'POST') {
      const dir = (lastSummary()?.runDir) || newestRunDir() || OUT_DIR;
      spawn('explorer.exe', [dir], { detached: true, stdio: 'ignore' }).unref();
      return send(res, 200, { ok: true, dir });
    }

    return send(res, 404, { ok: false, error: '没有这个接口' });
  } catch (error) {
    return send(res, 500, { ok: false, error: error.message });
  }
});

const URL_SELF = `http://127.0.0.1:${PORT}`;
function openBrowser() {
  try {
    spawn('cmd.exe', ['/c', 'start', '', URL_SELF], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } catch { /* 打不开就让用户手动点 */ }
}

server.on('error', error => {
  if (error.code === 'EADDRINUSE') {
    console.log('[控制台] 已经在运行了，直接帮你打开页面');
    openBrowser();
    setTimeout(() => process.exit(0), 600);
    return;
  }
  console.error('[控制台] 启动失败：' + error.message);
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[控制台] 已启动： ${URL_SELF}`);
  console.log(`[控制台] 店铺配置：${JSON.stringify(shopSummary())}`);
  console.log(`[控制台] 输出目录：${OUT_DIR}`);
  console.log('[控制台] 这个窗口保持开着就行，可以最小化；关掉窗口服务就停了（下载与常驻桥不受影响）。');
  if (!process.env.NO_OPEN) openBrowser();

  // 后台把常驻桥拉起来。连不上才提示，正常情况这里悄无声息。
  ensureEnv({
    openInspect: false,
    waitAuthMs: 0,
    onLog: text => say('[控制台] ' + text)
  }).then(r => {
    if (r.ok) {
      say('[控制台] 常驻连接已在线，本次及以后都不需要再点允许');
    } else if (r.needsAuth) {
      say('[控制台] 浏览器调试开关是关的：需要拨一次开关。点页面右上角「去开开关」即可，拨好后不用重启任何东西');
      broadcast('env', { needsAuth: true });
    } else if (r.reason) {
      say('[控制台] ' + r.reason);
    }
  }).catch(error => say('[控制台] 环境检查失败：' + error.message));
});
