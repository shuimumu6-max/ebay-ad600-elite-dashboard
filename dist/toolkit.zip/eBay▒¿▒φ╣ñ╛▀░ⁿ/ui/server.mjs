// eBay 报表控制台：本地网页界面 + 后台调用 download.mjs
// 只监听 127.0.0.1，不对外暴露；职责：环境体检、参数拼装、启动下载、实时日志、结果读取。
import http from 'node:http';
import { spawn } from 'node:child_process';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { basename, dirname, join, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ensureEnv, bridgeHealth, startBridgeDaemon, openInspectPage, findChrome } from '../app/ensure-env.mjs';
import { DATA_DIR, yesterdayPacific, monthStart, PLG_CAMPAIGNS, RC_RANGES, ACTIVE_TYPES, ORDER_TYPES, ORDER_RANGES, PRIORITY_TYPES, PRIORITY_CAMPAIGNS, PRIORITY_DEFAULT_IDS } from '../app/config.mjs';
import { dataDirState, dashboardMode } from '../app/publish.mjs';
import { scanGaps, pacificToday, clampScanRange, weekWindow, daySpan } from '../app/scan-gaps.mjs';
import { catalogSnapshot } from '../app/reports.mjs';
import { SHOP, shopSummary, configFilePath, saveConfigPatch } from '../app/shop-config.mjs';
import { planGapFill, tailSteps, waitBeforeStep, clampGapSec, groupPlgByPreset, GAP_DEFAULT_SEC } from './gap-plan.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const APP_DIR = join(here, '..', 'app');
const NODE = process.execPath;
const PORT = Number(process.env.CONSOLE_PORT || SHOP.consolePort);
let OUT_DIR = process.env.REPORT_OUT_DIR || SHOP.runsDir;
const LOG_FILE = join(here, 'console.log');
const DASHBOARD_URL = process.env.DASHBOARD_URL || SHOP.dashboardUrl;

// 新装（或换机器）时「数据」「下载结果」两个目录还不存在：先建好，
// 否则补缺 / 归档会在 scandir 上抛 ENOENT（已踩过一次）。
for (const dir of [OUT_DIR, SHOP.dataDir]) {
  try { mkdirSync(dir, { recursive: true }); } catch { /* 忽略：真写不进去会在下载时报更明确的错 */ }
}

// 活动列表可在运行中热更新（点「刷新活动列表」跑完自动扫描后不用重启控制台）：
// 空数组 = 报表中心后台默认的全部活动，这是默认状态，完全不需要配置。
let plgList = PLG_CAMPAIGNS;
let priorityList = PRIORITY_CAMPAIGNS;
let priorityDefault = PRIORITY_DEFAULT_IDS;
let shopMeta = { shopName: SHOP.shopName, sellerName: SHOP.sellerName || '' };
// null = 还没扫过；true/false = 下载结果目录里有没有 CSV（决定要不要显示「首次使用」引导）
let runsCsvSeen = null;
let runsCsvCheckedAt = 0;

function readJsonFile(path) {
  try { return JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, '')); } catch { return null; }
}

// 从磁盘重读活动配置：my-shop.json（PLP/PLG + 店铺名）+ app/priority-campaigns.json（活动名池）
function reloadCampaigns() {
  const config = readJsonFile(configFilePath()) || {};
  const normalize = list => (Array.isArray(list) ? list : [])
    .map(c => typeof c === 'string' ? { id: c, name: c } : { id: String(c?.id || ''), name: String(c?.name || c?.id || '') })
    .filter(c => c.id);
  plgList = normalize(config.plgCampaigns);
  const plpIds = (Array.isArray(config.plpCampaigns) ? config.plpCampaigns : []).map(String).filter(Boolean);
  const snapshot = readJsonFile(join(APP_DIR, 'priority-campaigns.json'));
  const owner = String(config.sellerName || shopMeta.sellerName || shopMeta.shopName || '').trim();
  const snapshotOwner = snapshot?.seller || snapshot?.shopName;
  const pool = snapshot && (!snapshotOwner || !owner || snapshotOwner === owner)
    ? normalize(snapshot.campaigns)
        .map(c => ({ ...c, plp: plpIds.includes(c.id) }))
    : plpIds.map(id => ({ id, name: id, plp: true }));
  priorityList = pool;
  priorityDefault = Array.isArray(config.priorityDefaultCampaigns)
    ? config.priorityDefaultCampaigns.map(String)
    : plpIds.filter(id => pool.some(c => c.id === id));
  shopMeta = {
    shopName: String(config.shopName || '').trim() || SHOP.shopName,
    sellerName: String(config.sellerName || shopMeta.sellerName || '').trim()
  };
  return { plgList, priorityList, priorityDefault, shopMeta };
}


// ---------- 运行态 ----------
let child = null;
let scanChild = null;                                // 活动扫描子进程（只读，不影响下载）
let runInfo = null;                                  // { startedAt, args, lines }
// 逐天串行队列：一键补齐全天跑完一天 → 等一会儿 → 再跑下一天（同一天重复提交容易被 eBay 拒）
let seq = null;                                      // { steps, i, gapMs, label, timer }
// 两路并行：流量一路、广告一路（报表中心按「请求行名」排队，PLG 与优先促刊行名相同，
// 这两类并发会互相认领文件，所以广告必须自己串行；流量行名不同，可以和广告同时跑）
let par = null;                                      // { label, queues, runDirs, procs }
let buffer = [];                                     // 最近日志行，供新连接补屏
const clients = new Set();                           // SSE 连接

const j = obj => JSON.stringify(obj);
const say = text => {
  const line = String(text);
  buffer.push(line);
  if (buffer.length > 3000) buffer.shift();
  for (const res of clients) res.write(`data: ${j({ line })}\n\n`);
  try { appendFileSync(LOG_FILE, line + '\n'); } catch { /* 忽略 */ }
};

function broadcast(event, payload) {
  for (const res of clients) res.write(`event: ${event}\ndata: ${j(payload)}\n\n`);
}

// 只读识别店铺名（跑 auto-scan.mjs --seller-only，约 5~10 秒）。成功返回卖家名。
function runSellerScan() {
  return new Promise((resolve, reject) => {
    const proc = spawn(NODE, [join(APP_DIR, 'auto-scan.mjs'), '--seller-only', '--json', '--quiet'], {
      cwd: dirname(APP_DIR), windowsHide: true
    });
    scanChild = proc;
    let out = '';
    proc.stdout.on('data', chunk => { out += String(chunk); });
    proc.stderr.on('data', chunk => { out += String(chunk); });
    const timer = setTimeout(() => {
      try { proc.kill(); } catch { /* 忽略 */ }
      reject(new Error('读取超时：浏览器没有响应，重新打开浏览器再试'));
    }, 60000);
    proc.on('close', () => {
      clearTimeout(timer);
      scanChild = null;
      reloadCampaigns();
      broadcast('shop', { name: shopMeta.shopName, seller: shopMeta.sellerName });
      const line = out.split(/\r?\n/).reverse().find(l => l.startsWith('@@result:'));
      let result = null;
      try { result = line ? JSON.parse(line.slice('@@result:'.length)) : null; } catch { /* 忽略 */ }
      if (result?.ok && result.seller) resolve(result.seller);
      else reject(new Error(result?.error || '没读到卖家名：确认浏览器已登录 eBay 卖家后台'));
    });
  });
}

// ---------- 首次初始化：一次把够用的历史数据下下来，看板一打开就有内容 ----------
// 口径（2026-11-10 定，与体检同口径）：「上周 + 本周」，即 上周一 ~ 太平洋昨天。
// 广告报表「按日」只给 今天/昨天/本周/上周，周界口径两份预设正好盖住；
// 流量逐日也下同一区间，周报看板天然对齐（上周 7 天 + 本周已过天数）。
function shiftDays(iso, days) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// 返回两路队列：流量·在售 一路，广告 一路（广告内部必须串行：PLG 与优先促刊行名相同）
function firstRunPlan() {
  const week = weekWindow();
  const end = week.end;
  const start = week.start;                      // 上周一
  const days = daySpan(start, end) + 1;          // 通常 8~14 天（看今天是周几）
  const base = ['run-download.mjs', '--out', OUT_DIR, '--max-tabs', '10'];
  // 并行下载：一次调用里同时下「流量 + 在售名单 + 广告」，download.mjs 内部是 Promise.all，
  // 各入口各开自己的标签页（流量走 performance 页，广告/名单走报表中心队列），互不抢。
  // 不能拆成两个进程并行 —— 桥的下载目录是全局设置，两个进程会互相把下载目录改到自己那边，
  // 文件落进对方目录就认领不到（实测 7 天流量只成功 3 天，就是这么丢的）。
  // 2026-11-10：--plg-range / --priority-range 支持逗号分隔多预设后，上周+本周的广告
  // 也进同一个进程（报表中心内部串行提交），原来「上周一步、本周第二步」的两进程拆法取消。
  const step1 = {
    day: '流量·名单·广告（上周+本周）',
    title: `流量（逐日 ${days} 份，${start} ~ ${end}）+ 在售名单 + 广告上周·本周（多入口并行，报表中心串行）`,
    // 只跑「逐日」：`--only traffic` 会同时开一条累计报表任务，两条 traffic 请求并行更容易被限速。
    args: [...base, '--only', 'trafficDaily,active,plg,priority',
      '--dates', `${start}..${end}`, '--date', end,
      '--active-type', 'active',
      '--plg-unit', 'DAILY', '--plg-range', 'LASTWEEK,CURRENTWEEK',
      // 默认只下物品列表：关键词 / 搜索词会拖慢首次初始化，看板上留空即可（需要时单独下）
      '--priority-types', 'listing',
      '--priority-unit', 'DAILY', '--priority-range', 'LASTWEEK,CURRENTWEEK']
  };
  const steps = [step1];
  const queues = [{ label: '本轮（并行）', steps }];
  return { steps, queues, start, end, days };
}

// 下载结果目录里有没有 CSV：新用户装完第一次打开时用来判断「要不要引导初始化」
function countCsv(dir) {
  let count = 0;
  const walk = d => {
    if (count > 500) return;
    let entries = [];
    try { entries = readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      if (entry.isDirectory()) walk(join(d, entry.name));
      else if (entry.name.toLowerCase().endsWith('.csv')) count++;
    }
  };
  if (dir && existsSync(dir)) walk(dir);
  return count;
}
const runsCsvCount = () => countCsv(OUT_DIR);

// ---------- 环境体检 ----------
// 只问常驻桥（毫秒级），不再每次做 8 秒的 WS 握手探测；
// 桥不在就顺手拉起守护，用户不用关心进程在不在。
let lastDaemonTry = 0;
async function envState() {
  let h = await bridgeHealth();
  if (!h && Date.now() - lastDaemonTry > 10000) {
    lastDaemonTry = Date.now();
    startBridgeDaemon();
  }
  // 首次引导看的是「正式目录」（看板的数据源），不是「下载结果」：
  // 之前用下载结果判断，一开下载卡片就消失，用户回头找不到「自动下载最近 2 周」了。
  // 15 秒最多扫一次目录，避免每次轮询都遍历几千个文件。
  if (runsCsvSeen === null || (!runsCsvSeen && Date.now() - runsCsvCheckedAt > 15000)) {
    runsCsvSeen = countCsv(DATA_DIR) > 0;
    runsCsvCheckedAt = Date.now();
  }
  const connected = !!h?.connected;
  // 「刚连上又掉一拍」和「开关真的关着」必须分开说。
  // 桥在重连的头几十秒里 needsAuth 也是 true，直接甩一句「去拨开关」，
  // 用户明明已经连上了会以为界面坏了（实测被吐槽过）。
  // 90 秒内成功连过 → 只说「正在恢复」，把主动权留在界面自己身上。
  const sinceOk = h?.lastConnectedAt ? Date.now() - h.lastConnectedAt : Infinity;
  const recovering = !connected && !!h && sinceOk < 90000 && !h.awaitingApproval;
  return {
    chrome: {
      ok: connected,
      browser: connected ? 'Chrome（常驻连接已在线）' : null,
      reason: connected ? null : (h?.hint || '常驻桥未启动')
    },
    bridge: {
      ok: connected,
      online: !!h,
      // recovering 时不暴露 waiting-auth / reconnecting 的细分，统一说「正在恢复」：
      // 这个状态下既不该让用户拨开关，也不该让他点「允许」。
      phase: connected ? 'connected' : (recovering ? 'reconnecting' : (h?.phase || 'offline')),
      needsAuth: connected ? false : (recovering ? false : !!h?.needsAuth),
      // true 表示「已经发起连接、Chrome 正在等用户点允许」，
      // 和「开关没开」是两种不同的处境，界面要给不同的话。
      awaitingApproval: connected ? false : (recovering ? false : !!h?.awaitingApproval),
      // true 表示调试端口其实已经开着（只是 Chrome 没接受这次连接）。
      // 界面据此把话说准，别让用户去拨一个本来就开着的开关。
      portOpen: !!h?.endpointPortOpen,
      recovering,
      lastConnectedAt: h?.lastConnectedAt || null,
      uptimeSec: h?.uptimeSec || 0,
      reconnectTries: h?.reconnectTries || 0,
      // 已连接时不能回退到「常驻桥未启动」——桥连着却提示未启动，用户会以为坏了。
      hint: connected
        ? null
        : recovering
          ? '刚才还连着，正在自动恢复…（一般几秒就好；超过 1 分钟还没好，再点「去开开关」）'
          : (h?.hint || (h ? '正在重连浏览器…' : '常驻桥未启动'))
    },
    running: !!child || !!seq || !!par,
    mode: runInfo?.mode || null,
    runStartedAt: runInfo?.startedAt || null,
    outDir: OUT_DIR,
    dashboard: DASHBOARD_URL,
    // 'online' = 维护者本机（有看板仓库，能推线上）；'local' = 发给运营的包（数据只留本机）
    dashboardMode: dashboardMode(),
    dataState: dataDirState(),
    // 新用户第一次打开：下载结果目录里还没有任何 CSV，就在页面上引导「自动下载最近 2 周」
    firstRun: {
      needed: !runsCsvSeen,
      days: 14,
      outDir: OUT_DIR,
      // 正式目录空、但下载结果里已有报表 → 不用重下，先归档那批就行
      pendingRuns: !runsCsvSeen ? runsCsvCount() : 0
    },
    shop: {
      name: shopMeta.shopName,
      seller: shopMeta.sellerName,
      // 还没识别出店铺名（新装用户）——界面会提示「点一下自动识别」
      placeholder: !shopMeta.shopName || shopMeta.shopName === '我的店铺',
      configFile: configFilePath(),
      // 0 个活动不是错：代表「报表中心后台默认全部活动」，也是最省事的默认状态
      plgCount: plgList.length,
      priorityCount: priorityList.length,
      campaignsMode: (plgList.length || priorityList.length) ? '指定活动' : '后台全部活动'
    },
    defaults: defaultForm(),
    // 程序文件在运行期间被「检查更新」换掉了：内存里跑的还是旧代码，
    // 不重启窗口就会一直看到旧行为（比如明明连上了还提示去拨开关）。
    staleBuild: buildStale(),
    last: lastSummary()
  };
}

// 下载类入口的统一前置条件：浏览器必须已经连上。
// 桥在重连、或者还在等 Chrome 授权时点「开始下载」，只会白等几十秒再弹一句「开关是关的」，
// 用户会以为工具坏了。所以服务端兜底拒绝，前端把按钮一起置灰（见 index.html applyConnectGate）。
const CONNECT_FIRST = '还没连上浏览器：先点右上角的「去开开关」，把 Allow remote debugging 拨到开；'
  + '顶部变成「已连接」之后再点下载';
async function requireBrowser(res) {
  const state = await bridgeHealth().catch(() => null);
  if (state?.connected) return true;
  send(res, 409, { ok: false, needsConnect: true, error: CONNECT_FIRST });
  return false;
}

// 启动时记下页面与服务的 mtime，运行中一变就说明文件被更新器替换过。
const BOOT_STAMPS = (() => {
  const out = {};
  for (const f of ['server.mjs', 'index.html']) {
    try { out[f] = statSync(join(here, f)).mtimeMs; } catch { out[f] = 0; }
  }
  return out;
})();
function buildStale() {
  for (const [f, stamp] of Object.entries(BOOT_STAMPS)) {
    try {
      if (statSync(join(here, f)).mtimeMs !== stamp) return true;
    } catch { /* 读不到就当没变化 */ }
  }
  return false;
}

function defaultForm() {
  const date = yesterdayPacific();
  return {
    date,
    rangeStart: monthStart(date),
    rangeEnd: date,
    // 空数组不是「没选」：空 = 报表中心后台默认的全部活动，下载侧不传活动参数
    plgCampaigns: plgList.map(c => c.id),
    plgCampaignList: plgList,
    ranges: RC_RANGES,
    activeTypes: Object.entries(ACTIVE_TYPES).map(([key, v]) => ({ key, label: v.label })),
    orderTypes: ORDER_TYPES.map(t => ({ key: t.key, label: t.label, mvp: t.mvp })),
    orderRanges: ORDER_RANGES,
    priorityTypes: PRIORITY_TYPES.map(t => ({ key: t.key, label: t.label, mvp: t.mvp, defaultOn: t.defaultOn !== false })),
    priorityCampaignList: priorityList,
    priorityDefaultCampaigns: priorityDefault,
    outDir: OUT_DIR
  };
}

function runDirsNewestFirst() {
  if (!existsSync(OUT_DIR)) return [];
  return readdirSync(OUT_DIR)
    .filter(name => /^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$/.test(name))
    .map(name => ({ name, at: statSync(join(OUT_DIR, name)).mtimeMs }))
    .sort((a, b) => b.at - a.at)
    .map(item => join(OUT_DIR, item.name));
}

function newestRunDir() {
  return runDirsNewestFirst()[0] || null;
}

function readSummary(dir) {
  const file = join(dir, '结果.json');
  if (!existsSync(file)) return null;
  try {
    const s = JSON.parse(readFileSync(file, 'utf8'));
    return {
      runDir: dir,
      runId: s.runId,
      totalMs: s.totalMs,
      date: s.date,
      rangeStart: s.rangeStart,
      plpStart: s.plpStart,
      plpEnd: s.plpEnd,
      counts: s.counts,
      warnings: s.warnings || [],
      errors: s.errors || [],
      files: (s.files || []).map(f => ({
        name: f.name, kind: f.kind, label: f.label, task: f.task,
        rowCount: f.rowCount, size: f.size, valid: f.valid, problem: f.problem || null,
        folder: (f.path || '').split(/[\\/]/).slice(-2, -1)[0] || ''
      }))
    };
  } catch { return null; }
}

// 只认本次：控制台这次启动后跑出来的结果。服务重开就是空白，不再回退历史目录，
// 免得把上一次的旧文件当成这次的产出。
function lastSummary() {
  if (!runInfo?.runDir) return null;
  return readSummary(runInfo.runDir);
}

// 最近的运行目录（带 结果.json 的），给「补做归档 + 更新看板」下拉框用
function recentRuns(limit = 20) {
  if (!existsSync(OUT_DIR)) return [];
  const out = [];
  for (const entry of readdirSync(OUT_DIR, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const dir = join(OUT_DIR, entry.name);
    const file = join(dir, '结果.json');
    if (!existsSync(file)) continue;
    try {
      const s = JSON.parse(readFileSync(file, 'utf8'));
      const files = (s.files || []).filter(f => f && f.path && f.valid !== false && !f.problem);
      out.push({
        name: entry.name, dir,
        startedAt: s.startedAt || '',
        only: Array.isArray(s.only) ? s.only : [],
        total: (s.counts?.total ?? (s.files || []).length),
        valid: (s.counts?.valid ?? files.length),
        archived: !!s.apply,
        published: !!s.publish,
        filesReady: files.filter(f => existsSync(f.path)).length
      });
    } catch { /* 坏的 结果.json 跳过 */ }
  }
  return out.sort((a, b) => (a.name < b.name ? 1 : -1)).slice(0, limit);
}

// ---------- 参数拼装 ----------
function buildArgs(form) {
  const out = String(form.outDir || '').trim();
  if (out && !isAbsolute(out)) throw new Error('结果目录要填 Windows 绝对路径');
  if (out.includes('..')) throw new Error('结果目录不能包含 ..');
  const args = ['run-download.mjs', '--out', out || OUT_DIR];
  const only = [];
  const tm = form.trafficMode || 'daily';
  if (tm === 'daily') only.push('trafficDaily');
  if (tm === 'range') only.push('trafficRange');
  if (tm === 'both') only.push('traffic');
  if (tm === 'batch') only.push('trafficDaily');
  if (form.plg) only.push('plg');
  if (form.active) only.push('active');
  if (form.orders) only.push('orders');
  if (form.priority) only.push('priority');
  if (!only.length) throw new Error('至少要选一份报表');

  args.push('--only', only.join(','));
  const maxTabs = Number(form.maxTabs || 4);
  if (Number.isFinite(maxTabs) && maxTabs >= 1 && maxTabs <= 10) args.push('--max-tabs', String(Math.round(maxTabs)));
  args.push('--date', form.date || yesterdayPacific());
  if (tm === 'batch') {
    const dates = String(form.batchDates || '').trim();
    if (!dates) throw new Error('批量模式需要填日期，如 2026-11-01..2026-11-05');
    args.push('--dates', dates);
  }
  if (tm === 'range' || tm === 'both') {
    args.push('--range-start', form.rangeStart);
    if (form.rangeEnd) args.push('--range-end', form.rangeEnd);
  }

  if (form.plg) {
    args.push('--plg-unit', form.plgUnit || 'DAILY');
    if (form.plgRange) args.push('--plg-range', form.plgRange);
    if (form.plgRange === 'CUSTOM') {
      if (!form.plgCustomStart || !form.plgCustomEnd) throw new Error('自定义区间要填起止日期');
      if (form.plgCustomStart > form.plgCustomEnd) throw new Error('自定义区间起始日晚于结束日');
      args.push('--plg-custom-start', form.plgCustomStart, '--plg-custom-end', form.plgCustomEnd);
    }
    // 活动列表：空 = 不传参数 = 报表中心后台默认的全部活动（推荐路径，运营不用管）。
    // 只有明确挑了「一部分活动」才传，用来缩小报表范围。
    const plgPicked = (form.plgCampaigns || []).filter(Boolean);
    if (plgPicked.length && plgList.length && plgPicked.length < plgList.length) {
      args.push('--plg-campaigns', plgPicked.join(','));
    }
  }
  if (form.active) args.push('--active-type', form.activeType || 'active');

  if (form.orders) {
    args.push('--order-type', form.orderType || 'all');
    args.push('--order-range', form.orderRange || 'LAST90D');
    if (form.orderRange === 'CUSTOM') {
      if (!form.orderCustomStart || !form.orderCustomEnd) throw new Error('订单自定义区间要填起止日期');
      if (form.orderCustomStart > form.orderCustomEnd) throw new Error('订单区间起始日晚于结束日');
      args.push('--order-custom-start', form.orderCustomStart, '--order-custom-end', form.orderCustomEnd);
    }
  }

  if (form.priority) {
    const ptypes = (form.priorityTypes || []).filter(Boolean);
    if (!ptypes.length) throw new Error('优先促销刊登至少要选一种报表类型');
    const bad = ptypes.filter(k => !PRIORITY_TYPES.some(t => t.key === k));
    if (bad.length) throw new Error(`优先促销刊登类型不支持：${bad.join(',')}`);
    args.push('--priority-types', ptypes.join(','));
    args.push('--priority-unit', form.priorityUnit || 'DAILY');
    if (form.priorityRange) args.push('--priority-range', form.priorityRange);
    if (form.priorityRange === 'CUSTOM') {
      if (!form.priorityCustomStart || !form.priorityCustomEnd) throw new Error('优先促刊自定义区间要填起止日期');
      if (form.priorityCustomStart > form.priorityCustomEnd) throw new Error('优先促刊区间起始日晚于结束日');
      args.push('--priority-custom-start', form.priorityCustomStart, '--priority-custom-end', form.priorityCustomEnd);
    }
    const pc = (form.priorityCampaigns || []).filter(Boolean);
    const known = new Set(priorityList.map(c => c.id));
    const unknown = pc.filter(id => !known.has(id));
    if (unknown.length) throw new Error(`优先促销刊登活动不在列表里：${unknown.join(',')}`);
    if (pc.length && pc.length < priorityList.length) args.push('--priority-campaigns', pc.join(','));
    else if (priorityList.length && pc.length === priorityList.length) args.push('--priority-campaigns', 'all');
  }
  if (form.keepTabs) args.push('--keep');
  // 控制台没有「发布看板」能力：老页面缓存传来的 publish 一律按归档处理
  if (form.publish || form.apply) args.push('--apply');
  return args;
}

// ---------- 一键补齐：扫描缺口 → 组参 → 下载 → 自动归档（看板是模板，不在这里发布） ----------
const dayList = (s, e) => {
  const out = [];
  for (let t = Date.parse(`${s}T00:00:00Z`); t <= Date.parse(`${e}T00:00:00Z`); t += 86400000) {
    out.push(new Date(t).toISOString().slice(0, 10));
  }
  return out;
};
// 报表中心「按日」粒度只给四个预设（实测 2026-11-08）：挑能整体盖住缺口的最小那个
function presetFor(days) {
  if (!days.length) return null;
  const fmt = x => x.toISOString().slice(0, 10);
  const shift = (x, n) => { const y = new Date(x); y.setUTCDate(y.getUTCDate() + n); return y; };
  const t0 = new Date(`${pacificToday()}T00:00:00Z`);
  const w0 = shift(t0, -(((t0.getUTCDay() + 6) % 7)));
  const presets = [
    ['TODAY', fmt(t0), fmt(t0)],
    ['YESTERDAY', fmt(shift(t0, -1)), fmt(shift(t0, -1))],
    ['CURRENTWEEK', fmt(w0), fmt(shift(w0, 6))],
    ['LASTWEEK', fmt(shift(w0, -7)), fmt(shift(w0, -1))]
  ];
  const lo = days[0];
  const hi = days[days.length - 1];
  const hit = presets.find(([, a, b]) => lo >= a && hi <= b);
  return hit ? hit[0] : null;
}

// 等同双击「打开看板.cmd」：交给 open-dashboard.mjs 开浏览器并打印数据位置。
// 之所以不在服务里直接读文件，是因为看板是纯前端 + 浏览器 IndexedDB，只能由浏览器打开。
function openLocalDashboard() {
  try {
    const proc = spawn(NODE, [join(APP_DIR, 'open-dashboard.mjs')], {
      cwd: join(here, '..'), windowsHide: true, stdio: 'ignore', detached: true
    });
    proc.unref();
    say('[控制台] 已打开本地看板（数据目录：数据/90-待处理）');
  } catch (error) {
    say(`[控制台] 打开看板失败：${error.message}`);
  }
}

// 统一启动后台任务：下载 / 归档 / 店铺识别共用日志流
function startJob(args, mode, label, onExit) {
  buffer = [];
  runInfo = { startedAt: Date.now(), args, runDir: null, mode };
  say(`[控制台] ${label}：${[NODE, ...args].join(' ')}`);
  broadcast('run', { phase: 'start', args, mode });

  child = spawn(NODE, args, { cwd: APP_DIR, windowsHide: true });
  let tail = '';
  const onData = chunk => {
    tail += chunk.toString('utf8');
    const parts = tail.split(/\r?\n/);
    tail = parts.pop() ?? '';
    for (const line of parts) {
      if (!line.trim()) continue;
      say(line);
      const m = /结果目录：(.*)$/.exec(line);
      if (m && runInfo) runInfo.runDir = m[1].trim();
    }
  };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);
  child.on('exit', code => {
    if (tail.trim()) say(tail.trim());
    // 只认本次自己报出来的结果目录；失败没报就是没有，不去抓历史目录充数
    const dir = runInfo?.runDir || null;
    if (runInfo) runInfo.runDir = dir;
    say(`[控制台] ${mode === 'publish' ? '归档' : mode === 'seller' ? '店铺识别' : '下载'}结束，退出码 ${code}`);
    // 本地看板模式：没有线上看板可推，归档完就是「看板可用」，把下一步说清楚。
    // 只在最后一步说一次——每归档一批就说一遍，日志会刷得人看不见重点。
    if (mode === 'publish' && code === 0 && dashboardMode() === 'local' && (!seq || seq.i + 1 >= seq.total)) {
      say('[控制台] 数据已归档到本机「数据」目录：点右上角「打开看板」就能看，报表会自动加载，不用手动选文件');
    }
    const summary = mode === 'publish' ? null : lastSummary();
    child = null;
    const queueMore = !!seq && (seq.i + 1 < seq.total || seq.thenArchive);
    broadcast('run', {
      phase: 'end', code, mode, summary, dashboard: DASHBOARD_URL,
      dataState: dataDirState(),
      queue: seq ? { index: seq.i + 1, total: seq.total, more: queueMore } : null
    });
    if (onExit) onExit(code);
  });
}

// 逐天串行：每一天跑完等 gapMs，再跑下一天；中间的空档也算「运行中」
// opts.thenArchive：所有下载步骤跑完后，自动补「逐个归档」步骤
function startSequence(steps, label, gapMs, opts = {}) {
  if (!steps.length) return;
  seq = {
    steps, i: 0, gapMs, label, timer: null, total: steps.length,
    runDirs: [], failures: [], thenArchive: !!opts.thenArchive
  };
  say(`[控制台] ${label}：共 ${steps.length} 步串行，步与步之间停 ${Math.round(gapMs / 1000)} 秒`);
  runSeqStep();
}

function runSeqStep() {
  if (!seq) return;
  const step = seq.steps[seq.i];
  const tag = step.title || `第 ${seq.i + 1}/${seq.total} 天（${step.day}）`;
  startJob(step.args, step.mode, `${seq.label} · ${tag}`, code => {
    if (!seq) return;                       // 已被手动停止
    // 店铺识别步骤：把新读到的卖家名 / 活动列表刷进界面（失败不拦后面的下载）
    if (step.mode === 'seller') {
      reloadCampaigns();
      broadcast('shop', { name: shopMeta.shopName, seller: shopMeta.sellerName });
      if (code === 0) say(`[控制台] 店铺已识别：${shopMeta.shopName}`);
    }
    if (step.mode === 'download') {
      const dir = runInfo?.runDir || null;
      if (dir) seq.runDirs.push(dir);
      if (code !== 0) seq.failures.push(`${step.day}（退出码 ${code}）`);
    }
    seq.i++;

    // 下载都跑完了：把「逐个归档」步骤补到队尾（运行目录要跑完才知道）
    if (seq.i >= seq.total && seq.thenArchive) {
      seq.thenArchive = false;
      const tail = tailSteps(seq.runDirs);
      seq.steps.push(...tail);
      seq.total = seq.steps.length;
      if (!seq.runDirs.length) say('[控制台] 这次没有任何下载成功，没有可归档的文件');
    }

    if (seq.i >= seq.total) {
      const fails = seq.failures;
      say(`[控制台] ${seq.label} 全部结束：共 ${seq.total} 步`
        + (fails.length ? `，失败 ${fails.length} 步：${fails.join('、')}` : '，全部成功'));
      // 多步任务最后一步是归档，它没有下载 summary，所以失败明细要在这里单独推给前端，
      // 否则用户只看到进度条走完、不知道该不该再补一次。
      broadcast('run', { phase: 'seq-end', label: seq.label, failures: fails, total: seq.total });
      seq = null;
      return;
    }

    // 等一下步：下载步骤之间要留间隔；归档不用等，跑完立刻接上
    const next = seq.steps[seq.i];
    const waitMs = waitBeforeStep(step, next, seq.gapMs);
    if (waitMs >= 1000) {
      say(`[控制台] ${tag} 结束，等 ${Math.round(waitMs / 1000)} 秒再跑下一步（${next.title || next.day}）…`);
      broadcast('run', { phase: 'gap', waitMs, next: next.title || next.day, index: seq.i + 1, total: seq.total });
      seq.timer = setTimeout(() => { if (seq) { seq.timer = null; runSeqStep(); } }, waitMs);
    } else {
      runSeqStep();
    }
  });
}

function stopSequence() {
  if (!seq) return false;
  if (seq.timer) clearTimeout(seq.timer);
  seq = null;
  return true;
}

// ---------- 两路并行（首次初始化用） ----------
// 收益：2 周的流量报表是最慢的一段（逐日 14 份、串行提交），把广告那几份放到另一路同时跑，
// 总时长就从「流量 + 广告」降到「流量」。
function startParallel(label, queues) {
  buffer = [];
  runInfo = { startedAt: Date.now(), args: [], runDir: null, mode: 'parallel' };
  par = {
    label, startedAt: Date.now(), runDirs: [], procs: new Set(),
    queues: queues.map(q => ({ label: q.label, steps: q.steps, i: 0, running: false, failures: [] }))
  };
  say(`[控制台] ${label}：${queues.length} 路并行（${queues.map(q => q.label).join(' / ')}）；同一路内部仍然串行，避免报表中心认错文件`);
  broadcast('run', { phase: 'start', mode: 'parallel' });
  pumpParallel();
}

function pumpParallel() {
  if (!par) return;
  for (const q of par.queues) {
    if (!q.running && q.i < q.steps.length) spawnQueueStep(q);
  }
  if (par.queues.every(q => !q.running && q.i >= q.steps.length)) finishParallel();
}

function spawnQueueStep(q) {
  const step = q.steps[q.i];
  q.running = true;
  say(`[控制台] [${q.label}] 开始：${step.title || step.day}`);
  const proc = spawn(NODE, step.args, {
    cwd: APP_DIR,
    windowsHide: true,
    // 并行时两路共用同一个浏览器窗口，谁都不许清「历史 /sh 页」，否则会把另一路的页面关掉
    env: { ...process.env, EBAY_KEEP_TABS: '1' }
  });
  par.procs.add(proc);
  let tail = '';
  const onData = chunk => {
    tail += chunk.toString('utf8');
    const parts = tail.split(/\r?\n/);
    tail = parts.pop() ?? '';
    for (const line of parts) {
      if (!line.trim()) continue;
      say(`[${q.label}] ${line}`);
      const m = /结果目录：(.*)$/.exec(line);
      if (m && par) par.runDirs.push(m[1].trim());
    }
  };
  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);
  proc.on('exit', code => {
    if (tail.trim()) say(`[${q.label}] ${tail.trim()}`);
    par?.procs.delete(proc);
    q.running = false;
    if (code !== 0) q.failures.push(`${step.title || step.day}（退出码 ${code}）`);
    q.i++;
    pumpParallel();
  });
}

function finishParallel() {
  if (!par) return;
  const { label, queues, runDirs, startedAt } = par;
  const fails = queues.flatMap(q => q.failures);
  const mins = Math.round((Date.now() - startedAt) / 60000 * 10) / 10;
  say(`[控制台] ${label} 全部结束：用时 ${mins} 分钟，得到 ${runDirs.length} 个结果目录`
    + (fails.length ? `，失败 ${fails.length} 步：${fails.join('、')}` : '，全部成功'));
  par = null;
  runInfo = null;
  broadcast('run', { phase: 'end', code: fails.length ? 1 : 0, mode: 'parallel', summary: lastSummary(), dashboard: DASHBOARD_URL, dataState: dataDirState() });
}

function stopParallel() {
  if (!par) return false;
  for (const proc of par.procs) { try { proc.kill(); } catch { /* 忽略 */ } }
  par = null;
  runInfo = null;
  return true;
}

// ---------- HTTP ----------
function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' ? body : j(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 1e6) reject(new Error('请求过大')); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('请求不是合法 JSON')); } });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const path = url.pathname;

  try {
    if (path === '/' || path === '/index.html') {
      const file = join(here, 'index.html');
      return send(res, 200, readFileSync(file, 'utf8'), 'text/html; charset=utf-8');
    }
    if (path === '/api/state') return send(res, 200, await envState());

    // 改店铺名：名字只是个标签，界面上随手改，写回 my-shop.json
    if (path === '/api/shop-name' && req.method === 'POST') {
      const body = await readBody(req);
      const name = String(body.name || '').trim().slice(0, 40);
      try {
        const saved = saveConfigPatch({ shopName: name });
        shopMeta.shopName = name || SHOP.shopName;
        broadcast('shop', { name: shopMeta.shopName });
        say(`[控制台] 店铺名已改为「${shopMeta.shopName}」（写入 ${saved}）`);
        return send(res, 200, { ok: true, name: shopMeta.shopName, file: saved });
      } catch (error) {
        return send(res, 500, { ok: false, error: `保存失败：${error.message}` });
      }
    }

    // 识别店铺名：只读浏览器里的卖家账号，几秒完成，不碰活动列表、不下载。
    // 新装用户第一次点「识别 / 改名」就走这里，不需要手填店铺名。
    if (path === '/api/detect-shop' && req.method === 'POST') {
      if (child || seq || scanChild || par) return send(res, 409, { ok: false, error: '有任务在跑，等它结束再识别' });
      const state = await bridgeHealth().catch(() => null);
      if (!state?.connected) {
        return send(res, 200, { ok: false, error: '浏览器还没连上：先点页面顶部的「去开开关」，再点一次识别' });
      }
      try {
        const name = await runSellerScan();
        say(`[控制台] 店铺已识别：${name}`);
        return send(res, 200, { ok: true, name, seller: shopMeta.sellerName });
      } catch (error) {
        return send(res, 200, { ok: false, error: error.message });
      }
    }

    // 刷新活动列表（可选功能）：只读扫描报表中心的 Campaigns 卡片，把活动名填进下拉框。
    // 不点也完全能用——活动留空就是「后台默认全部活动」。
    if (path === '/api/auto-scan' && req.method === 'POST') {
      if (scanChild || child || seq || par) return send(res, 409, { ok: false, error: '有任务在跑，等它结束再刷新活动列表' });
      say('[控制台] 开始扫描报表中心的活动列表（只读，不提交任何下载）…');
      const proc = spawn(NODE, [join(APP_DIR, 'auto-scan.mjs'), '--json'], { cwd: dirname(APP_DIR), windowsHide: true });
      scanChild = proc;
      let out = '';
      const onData = chunk => {
        const text = String(chunk);
        out += text;
        for (const line of text.split(/\r?\n/)) {
          if (!line.trim() || line.startsWith('@@')) continue;
          say(line);
        }
      };
      proc.stdout.on('data', onData);
      proc.stderr.on('data', onData);
      proc.on('close', code => {
        scanChild = null;
        const lists = reloadCampaigns();
        const payload = { ok: code === 0, ...lists };
        const resultLine = out.split(/\r?\n/).reverse().find(l => l.startsWith('@@result:'));
        if (resultLine) {
          try { payload.result = JSON.parse(resultLine.slice('@@result:'.length)); } catch { /* 忽略 */ }
        }
        say(code === 0
          ? `[控制台] 活动列表已刷新：PLG ${lists.plgList.length} 个 / 优先促刊 ${lists.priorityList.length} 个`
          : '[控制台] 活动扫描没成功，不影响使用：留空就是后台全部活动，直接下载即可');
        broadcast('scan-done', payload);
        broadcast('shop', { name: shopMeta.shopName });
      });
      return send(res, 200, { ok: true, started: true });
    }

    // 需要授权时：拉起守护 + 在浏览器里打开开关页面，用户拨一次即可
    if (path === '/api/fix-env' && req.method === 'POST') {
      if (!findChrome()) return send(res, 500, { ok: false, error: '没找到 Chrome 安装路径' });
      startBridgeDaemon();
      const opened = openInspectPage();
      say(opened
        ? '[控制台] 已打开 chrome://inspect 开关页面：把 Allow remote debugging 拨到开，之后就不用再管了'
        : '[控制台] 请在浏览器地址栏打开 chrome://inspect/#remote-debugging 并拨开开关');
      return send(res, 200, { ok: opened, needsAuth: true });
    }

    if (path === '/api/preview' && req.method === 'POST') {
      const form = await readBody(req);
      try { return send(res, 200, { ok: true, command: [NODE, ...buildArgs(form)].join(' ') }); }
      catch (error) { return send(res, 200, { ok: false, error: error.message }); }
    }

    if (path === '/api/logs') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-store',
        Connection: 'keep-alive'
      });
      res.write('retry: 2000\n\n');
      res.write(`event: snapshot\ndata: ${j({ lines: buffer.slice(-400) })}\n\n`);
      clients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => { clearInterval(ping); clients.delete(res); });
      return;
    }

    // 首次初始化：一键下载「上周 + 本周」（Traffic 逐日 + PLG 上周/本周 + 优先促刊 + 在售名单）。
    // 目的是让新装的人打开看板就有数据，不用先研究「该下哪些报表、什么粒度」。
    if (path === '/api/first-run' && req.method === 'POST') {
      if (child || seq || scanChild || par) return send(res, 409, { ok: false, error: '已有任务在跑，先等它结束' });
      const body = await readBody(req).catch(() => ({}));
      const plan = firstRunPlan();
      if (body.dryRun) {
        return send(res, 200, {
          ok: true, dryRun: true, start: plan.start, end: plan.end,
          queues: plan.queues.map(q => ({ label: q.label, steps: q.steps.map(s => ({ day: s.day, title: s.title })) })),
          steps: plan.steps.map(s => ({ day: s.day, title: s.title, args: s.args }))
        });
      }
      // 第 1 步永远是「跟店铺后台连上」：连不上就直接说，不要让人等半小时才发现
      const state = await bridgeHealth().catch(() => null);
      if (!state?.connected) {
        return send(res, 409, { ok: false, needsConnect: true, error: CONNECT_FIRST });
      }
      say(`[控制台] 首次初始化：流量 ${plan.days} 天（${plan.start} ~ ${plan.end}，上周 + 本周）+ 在售名单 + 广告（上周/本周），多入口并行下载；全程只读，不改动任何已有数据`);
      // 先把店铺名读出来（只读，几秒），读不到也不拦着下载
      try { await runSellerScan(); } catch (error) { say(`[控制台] 店铺名没读到（不影响下载）：${error.message}`); }
      // 一步一步来：实测两路并行时，两个进程抢同一个浏览器窗口和同一个下载目录，
      // 流量那一摞会大量失败（7 天只拿到 3 天）——宁可控场慢一点，也不要下不全。
      // thenArchive：下完自动归档进「数据」，不用再让用户找「归档」按钮（小白最容易卡在这一步）。
      startSequence(plan.steps.map(step => ({ ...step, mode: 'download' })), `首次初始化（${plan.start} ~ ${plan.end}）`, 0, { thenArchive: true });
      return send(res, 200, {
        ok: true, started: true, start: plan.start, end: plan.end, days: plan.days,
        queues: plan.queues.map(q => ({ label: q.label, steps: q.steps.map(s => ({ day: s.day, title: s.title })) }))
      });
    }

    // 一键补齐：扫描正式目录的缺口 → 只下载缺的那些 → 归档 → 更新看板
    // 口径（2026-11-08 定）：看板日更 = 流量单日 + PLG 链接广告 + PLP 链接广告（走 campaign 页）
    if (path === '/api/gap-fill' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '已有任务在跑，先等它结束' });
      if (!(await requireBrowser(res))) return;
      // 补齐范围和界面上「体检区间」保持一致：看到的是「上周 + 本周」，补的也只补这个区间，
      // 不会因为你选了个短区间，后台反而去补几个月的窟窿。
      const form = await readBody(req).catch(() => ({}));
      const scanRange = clampScanRange(form.range !== undefined ? form.range : form.days);
      let scanned;
      try { scanned = await scanGaps({ dashboardUrl: DASHBOARD_URL, range: scanRange }); }
      catch (error) { return send(res, 500, { ok: false, error: `扫描失败：${error.message}` }); }
      const byKey = Object.fromEntries(scanned.rows.map(r => [r.key, r]));
      const winStart = scanned.windowStart;
      const winEnd = scanned.windowEnd;
      // dryRun：只回「打算怎么补」，不真的下载（自检与 AI 安装说明用，避免误跑十几分钟）
      const dryRun = !!form.dryRun;
      const reply = (payload) => {
        if (!dryRun) return send(res, 200, payload);
        return send(res, 200, {
          ok: true, dryRun: true, started: false,
          mode: payload.mode || (payload.started ? 'gap' : 'none'),
          message: payload.message || null,
          scanRange, windowStart: winStart, windowEnd: winEnd,
          days: payload.days || [], start: payload.start, end: payload.end,
          steps: (payload.steps || []).map(x => ({ day: x.day, title: x.title || null }))
        });
      };

      // 情形一：一条数据都没有（全新安装 / 换电脑）→ 等价于「首次初始化」。
      // 下载结果里已经有上次跑出来的报表时先归档那批，别让人白下一遍。
      if (scanned.allEmpty) {
        const pending = newestRunDir();
        const pendingCsv = pending ? countCsv(pending) : 0;
        if (pendingCsv > 0) {
          say(`[控制台] 正式目录还没有数据，但下载结果里有现成的（${basename(pending)}，${pendingCsv} 份 CSV）：先归档它并更新看板`);
          if (!dryRun) startSequence(tailSteps([pending]), '归档未处理的下载结果', 0);
          return reply({
            ok: true, started: true, mode: 'archive',
            scanRange, windowStart: winStart, windowEnd: winEnd,
            message: `下载结果里有 ${pendingCsv} 份现成报表，已开始归档并更新看板；回来看还缺就再点一次`
          });
        }
        const plan = firstRunPlan();
        say(`[控制台] 体检发现正式目录一条数据都没有：按首次初始化下载「上周 + 本周」（${plan.start} ~ ${plan.end}，流量逐日 + 在售名单 + 广告），跑完自动归档并更新看板`);
        try { await runSellerScan(); } catch (error) { say(`[控制台] 店铺名没读到（不影响下载）：${error.message}`); }
        if (!dryRun) startSequence(plan.steps.map(step => ({ ...step, mode: 'download' })), `首次初始化（${plan.start} ~ ${plan.end}）`, 0, { thenArchive: true });
        return reply({
          ok: true, started: true, mode: 'first-run', days: plan.days, start: plan.start, end: plan.end,
          scanRange, windowStart: winStart, windowEnd: winEnd,
          message: `还没有任何数据，已按首次初始化开始下载「上周 + 本周」（${plan.start} ~ ${plan.end}），跑完自动归档并更新看板`
        });
      }

      // 情形二：有数据但存在缺口 → 逐天补齐（某类从零开始的话，整个区间都要下）
      const daysOf = key => {
        const r = byKey[key];
        if (!r) return [];
        if (r.nothingYet) return dayList(r.windowStart, r.windowEnd);
        return (r.missingRanges || []).flatMap(x => dayList(x.start, x.end));
      };
      const trafficDays = daysOf('trafficDaily');
      const plgDays = daysOf('plg');
      // PLG 按日只有 今天/昨天/本周/上周：缺口跨两周就拆成两步，超出上周的日子只能跳过并说明
      const { groups: plgGroups, unfillable: plgUnfillable } = groupPlgByPreset(plgDays, pacificToday());
      const plgFillable = plgDays.filter(d => !plgUnfillable.includes(d));
      if (plgUnfillable.length) {
        say(`[控制台] PLG 有 ${plgUnfillable.length} 天（${plgUnfillable[0]} ~ ${plgUnfillable[plgUnfillable.length - 1]}）超出 eBay「按日」可选范围（最早只到上周），这几天补不了，先补能补的`);
      }
      // PLP 走 campaign 页通道，必须知道具体活动；活动留空（= 后台全部）时这一路补不了，
      // 直接跳过 PLP、只补流量和 PLG，不让用户卡在一个他没法填的配置项上。
      // 只补物品列表（Listing）：关键词 / 搜索词默认不下载，体检里只是「仅提醒」，不参与补齐
      const plpDaysRaw = [...new Set(daysOf('plpListing'))].sort();
      const plpDays = priorityDefault.length ? plpDaysRaw : [];
      if (!priorityDefault.length && plpDaysRaw.length) {
        say(`[控制台] 跳过 PLP 补齐：当前没指定活动（${plpDaysRaw.length} 天缺口）。PLP 报表需要具体活动，需要补就在「优先促刊」里勾几个活动。`);
      }

      if (!trafficDays.length && !plgGroups.length && !plpDays.length) {
        return reply({
          ok: true, started: false,
          message: plgUnfillable.length
            ? `只剩 ${plgUnfillable.length} 天 PLG 超出 eBay 可选范围，补不了；可以直接「只更新看板」`
            : '没有缺口，直接更新看板就行'
        });
      }

      const allDays = [...new Set([...trafficDays, ...plpDays])].sort();
      // 步与步之间停几秒（默认 8 秒）：现在一个进程里批量跑，步骤只剩「流量+PLP / PLG 上周 / PLG 本周」三步左右，
      // 不同报表类型之间不需要等一分半；真被限速时下载脚本自己会放慢并止损
      const gapSec = clampGapSec(form.gapSec);
      const { steps } = planGapFill({
        trafficDays, plgDays: plgFillable, plpDays, plgGroups,
        outDir: OUT_DIR, campaigns: priorityDefault, gapSec
      });
      if (!dryRun) startSequence(steps, '一键补齐缺口', gapSec * 1000, { thenArchive: true });
      return reply({
        ok: true, started: true, gapSec,
        scanRange, windowStart: winStart, windowEnd: winEnd,
        days: allDays,
        steps: steps.map(s => ({ day: s.day, args: s.args })),
        plan: {
          trafficDays,
          plgDays: plgFillable,
          plgUnfillable,
          plgPreset: plgGroups.length === 1 ? plgGroups[0].preset : (plgGroups.map(g => g.preset).join(' + ') || null),
          plpDays,
          plpRange: plpDays.length ? [plpDays[0], plpDays[plpDays.length - 1]] : null
        }
      });
    }

    if (path === '/api/run' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '已经有一次下载在跑，先停止或等它结束' });
      if (!(await requireBrowser(res))) return;
      const form = await readBody(req);
      let args;
      try { args = buildArgs(form); } catch (error) { return send(res, 400, { ok: false, error: error.message }); }
      const customOut = String(form.outDir || '').trim();
      if (customOut) OUT_DIR = customOut;
      startJob(args, 'download', '开始下载');
      return send(res, 200, { ok: true, args });
    }

    // 打开看板（本地看板自动读数据目录，没有「发布」动作——控制台不提供更新看板能力）
    if (path === '/api/publish' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '正在跑别的任务，等它结束再打开看板' });
      openLocalDashboard();
      return send(res, 200, { ok: true, local: true, message: '看板自动读取本机数据目录，已帮你打开' });
    }

    // 打开本地看板（本地模式专用）
    if (path === '/api/open-dashboard' && req.method === 'POST') {
      if (!existsSync(join(APP_DIR, 'open-dashboard.mjs'))) return send(res, 404, { ok: false, error: '这个版本的包里没有看板启动器' });
      openLocalDashboard();
      return send(res, 200, { ok: true });
    }

    // 最近几次运行：给「补做归档 + 更新看板」用
    if (path === '/api/runs') return send(res, 200, { ok: true, runs: recentRuns() });

    // 对已完成的运行补做归档：不重新下载，直接按 结果.json 把有效文件补进正式目录（不发布）
    if (path === '/api/archive-publish' && req.method === 'POST') {
      if (child || seq || par) return send(res, 409, { ok: false, error: '正在跑别的任务，等它结束再归档' });
      const form = await readBody(req);
      const runDir = String(form.runDir || '').trim();
      if (runDir && !isAbsolute(runDir)) return send(res, 400, { ok: false, error: '运行目录要填绝对路径' });
      const args = ['archive-publish.mjs', '--no-publish'];
      if (runDir) args.push('--run', runDir);
      const tag = runDir ? runDir.split(/[\\/]/).filter(Boolean).pop() : '最近一次运行';
      startJob(args, 'publish', `归档下载结果（${tag}）`);
      return send(res, 200, { ok: true });
    }

    if (path === '/api/data-state') return send(res, 200, { ok: true, state: dataDirState(), dashboard: DASHBOARD_URL });

    // 报表注册表 + 字段字典：控制台「字段」页用，静态数据，直接从 reports.mjs 读
    if (path === '/api/catalog') return send(res, 200, { ok: true, ...catalogSnapshot() });

    // 看板数据体检：正式目录里每类报表哪天有、哪天缺（今天与上架前不算缺）
    if (path === '/api/scan') {
      const scanRange = clampScanRange(url.searchParams.get('range') !== null
        ? url.searchParams.get('range')
        : url.searchParams.get('days'));
      const report = await scanGaps({ dashboardUrl: `${DASHBOARD_URL}data.js`, range: scanRange });
      say(`[控制台] 体检完成：${report.rows.length} 类报表，区间 ${report.windowStart} ~ ${report.windowEnd}`
        + `（${report.windowDays} 天），共缺 ${report.totalMissing} 天`);
      return send(res, 200, report);
    }

    if (path === '/api/stop' && req.method === 'POST') {
      const hadSeq = stopSequence();
      const hadPar = stopParallel();
      if (!child) {
        if (hadSeq) say('[控制台] 已停止逐天补齐队列（等待中的下一步不再执行）');
        if (hadPar) say('[控制台] 已停止两路并行下载（流量 / 广告都停了）');
        return send(res, 200, { ok: true, stopped: hadSeq || hadPar });
      }
      child.kill();
      say(hadSeq
        ? '[控制台] 已请求停止当前下载，逐天队列一并取消'
        : '[控制台] 已请求停止当前下载');
      return send(res, 200, { ok: true, stopped: true });
    }

    if (path === '/api/last') return send(res, 200, { ok: true, summary: lastSummary() });

    if (path === '/api/open' && req.method === 'POST') {
      const dir = (lastSummary()?.runDir) || newestRunDir() || OUT_DIR;
      spawn('explorer.exe', [dir], { detached: true, stdio: 'ignore' }).unref();
      return send(res, 200, { ok: true, dir });
    }

    return send(res, 404, { ok: false, error: '没有这个接口' });
  } catch (error) {
    return send(res, 500, { ok: false, error: error.message });
  }
});

const URL_SELF = `http://127.0.0.1:${PORT}`;
function openBrowser() {
  try {
    spawn('cmd.exe', ['/c', 'start', '', URL_SELF], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } catch { /* 打不开就让用户手动点 */ }
}

server.on('error', error => {
  if (error.code === 'EADDRINUSE') {
    console.log('[控制台] 已经在运行了，直接帮你打开页面');
    openBrowser();
    setTimeout(() => process.exit(0), 600);
    return;
  }
  console.error('[控制台] 启动失败：' + error.message);
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[控制台] 已启动： ${URL_SELF}`);
  console.log(`[控制台] 店铺配置：${JSON.stringify(shopSummary())}`);
  console.log(`[控制台] 输出目录：${OUT_DIR}`);
  console.log('[控制台] 这个窗口保持开着就行，可以最小化；关掉窗口服务就停了（下载与常驻桥不受影响）。');
  if (!process.env.NO_OPEN) openBrowser();

  // 后台把常驻桥拉起来。连不上才提示，正常情况这里悄无声息。
  ensureEnv({
    openInspect: false,
    waitAuthMs: 0,
    onLog: text => say('[控制台] ' + text)
  }).then(r => {
    if (r.ok) {
      say('[控制台] 常驻连接已在线，本次及以后都不需要再点允许');
    } else if (r.needsAuth) {
      say('[控制台] 浏览器调试开关是关的：需要拨一次开关。点页面右上角「去开开关」即可，拨好后不用重启任何东西');
      broadcast('env', { needsAuth: true });
    } else if (r.reason) {
      say('[控制台] ' + r.reason);
    }
  }).catch(error => say('[控制台] 环境检查失败：' + error.message));
});
