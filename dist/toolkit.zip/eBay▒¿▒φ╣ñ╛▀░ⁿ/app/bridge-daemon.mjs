// 桥守护：保证「本地常驻桥」永远有一个在跑。
// 用 Node 写而不是 VBS，是因为要区分端口占用 / 正常重启，避免守护和桥互相踢。
// 由 start-bridge.vbs 以无窗口方式拉起，并放进开机启动项。
import { spawn } from 'node:child_process';
import { appendFileSync, existsSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const logFile = join(here, 'bridge-daemon.log');
const BRIDGE = join(here, 'cdp-bridge.mjs');
const HEALTH = 'http://127.0.0.1:9233/health';

const log = text => {
  const line = `${new Date().toISOString()} [守护] ${text}`;
  console.log(line);
  try {
    if (existsSync(logFile) && statSync(logFile).size > 512 * 1024) return;
    appendFileSync(logFile, line + '\n');
  } catch { /* 忽略 */ }
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function healthy() {
  try {
    const res = await fetch(HEALTH, { signal: AbortSignal.timeout(1500) });
    if (!res.ok) return null;
    return await res.json();
  } catch { return null; }
}

// 已经有一个健康的桥在跑，本守护直接退出，不要出现两个守护抢同一个端口
const existing = await healthy();
if (existing) {
  log(`已有桥在运行（pid ${existing.pid ?? '未知'}），本守护退出。`);
  process.exit(0);
}

log('守护启动，负责让桥一直在线。');

let quickFails = 0;
for (;;) {
  const startedAt = Date.now();
  log('启动桥进程…');
  const child = spawn(process.execPath, [BRIDGE], {
    cwd: here, stdio: 'ignore', windowsHide: true,
    // 必须 detached：Windows 上未 detached 的子进程会被绑进父进程的 Job，
    // 父进程一退出（关控制台、守护被结束）桥就跟着死。桥一死，重新连 Chrome
    // 就要用户再去 chrome://inspect 点一次「允许」——这是最招人烦的问题。
    // 桥是常驻服务，必须完全脱离父进程，只由本守护在它真死时重启。
    detached: true
  });
  child.on('error', error => log('桥启动失败：' + error.message));

  const code = await new Promise(resolve => child.on('exit', resolve));
  const livedMs = Date.now() - startedAt;

  if (livedMs < 5000) quickFails += 1; else quickFails = 0;

  if (code === 0) {
    // code 0 = 桥主动退出，最常见是「端口已被占用」（另一个桥/守护已经在服务）。
    // 这种情况下本守护必须退出，否则会每 60 秒空转一次、还一直往日志里写，
    // 装了两份工具的机器就会看到两个守护互相踢。
    const live = await healthy();
    if (live) {
      log(`已有别的桥在服务（pid ${live.pid ?? '未知'}），本守护退出，不再空转。`);
      process.exit(0);
    }
    log(`桥退出（code 0，存活 ${Math.round(livedMs / 1000)}s），60 秒后重新检查。`);
    await sleep(60000);
  } else if (quickFails >= 5) {
    log(`桥连续 ${quickFails} 次快速退出，等待 120 秒后重试（避免空转）。`);
    await sleep(120000);
    quickFails = 0;
  } else {
    log(`桥异常退出（code ${code}，存活 ${Math.round(livedMs / 1000)}s），3 秒后重启。`);
    await sleep(3000);
  }
}
