// 店铺 / 机器配置：迁移到另一家店铺或另一台电脑，只改这一个文件，主链路代码不用动。
//
// 设计原则（2026-11-09 定）：**能自动的一律不要让运营填**。
//   - 店铺名：可空，空着显示「我的店铺」，界面上随时能改；
//   - PLP / PLG 活动：可空，空着就是「报表中心后台默认的全部活动」——
//     报表 CSV 里本来就带 Campaign 列，看板直接读报表，不需要先知道活动 ID；
//   - 只有三个目录（dataDir / runsDir / downloadsDir）必须落盘，安装器已经自动填好。
//
// 两种方式（任选其一）：
//   1. 直接改下面 DEFAULTS 里的值；
//   2. 程序目录放一份 my-shop.json（安装器会自动生成），或用环境变量
//      EBAY_SHOP_CONFIG=C:\path\to\my-shop.json 指向它。
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = dirname(HERE);

// 优先促销刊登的活动池：来自后台 Campaigns 卡片实采快照（只读探查，不是猜的）。
// 没有快照也不影响使用——控制台活动留空就等于「后台默认全部活动」，
// 快照只是让下拉框能显示活动名、方便只挑主力活动。
function readPriorityCampaigns(expectedShop, expectedSeller) {
  try {
    const path = join(HERE, 'priority-campaigns.json');
    if (!existsSync(path)) return [];
    const data = JSON.parse(readFileSync(path, 'utf8'));
    // 迁移到新店铺时不能沿用上一家店的活动：快照带店铺归属，不匹配就忽略。
    // 优先比卖家账号（稳定），没有 seller 字段时才比店铺名。
    const snapshotOwner = data.seller || data.shopName;
    const currentOwner = expectedSeller || expectedShop;
    if (snapshotOwner && currentOwner && snapshotOwner !== currentOwner) {
      console.warn(`[店铺配置] 活动快照属于「${snapshotOwner}」，当前是「${currentOwner}」，已忽略；需要活动名就重跑 node app\\auto-scan.mjs`);
      return [];
    }
    return normalizeCampaigns(data.campaigns);
  } catch { return []; }
}

function normalizeCampaigns(list) {
  return (Array.isArray(list) ? list : [])
    .map(c => typeof c === 'string' ? { id: c, name: c } : { id: String(c?.id || ''), name: String(c?.name || c?.id || '') })
    .filter(c => c.id);
}

// 当前店铺的默认值。
// 关键：这里的路径必须是「相对于本工具包」的，不能写死某台电脑的目录 ——
// 分发包发到别人电脑上时没有 my-shop.json，全靠这份默认值，写死维护者路径会在
// 运营机器上建出 C:\Users\xxx\Desktop\ebay ad600 Elite... 这种莫名其妙的目录。
// 维护者本机用自己的 my-shop.json 覆盖（不进分发包），想改默认行为就改那里。
const DEFAULTS = {
  shopName: '',
  dataDir: join(PROJECT_ROOT, '数据'),
  runsDir: join(PROJECT_ROOT, '下载结果'),
  downloadsDir: join(homedir(), 'Downloads'),
  dashboardUrl: '',
  // 空 = 报表中心后台的「全部活动」，不需要运营先知道活动 ID
  plpCampaigns: [],
  plgCampaigns: [],
  consolePort: 7788,
  bridgePort: 9233,
  chromeExe: ''
};

// 当前实际生效的配置文件路径（改名、自动扫描都写回这里）
let activeConfigPath = '';

function readOverride() {
  // 优先级：环境变量 EBAY_SHOP_CONFIG → 程序目录下的 my-shop.json → 内置默认值。
  // 第二个入口专为「不懂环境变量」的运营准备：安装目录里放一个 my-shop.json 就生效。
  const envPath = process.env.EBAY_SHOP_CONFIG;
  const localPath = join(PROJECT_ROOT, 'my-shop.json');
  if (!activeConfigPath) activeConfigPath = envPath || localPath;
  const candidates = envPath ? [envPath, localPath] : [localPath];
  for (const path of candidates) {
    if (!existsSync(path)) {
      if (path === envPath) console.warn(`[店铺配置] EBAY_SHOP_CONFIG 指向的文件不存在：${path}，继续找安装目录的 my-shop.json`);
      continue;
    }
    try {
      const data = JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
      activeConfigPath = path;
      console.log(`[店铺配置] 已读取：${path}`);
      return data;
    } catch (error) {
      console.warn(`[店铺配置] 读取失败（${error.message}）：${path}`);
    }
  }
  return {};
}

export const configFilePath = () => activeConfigPath || join(PROJECT_ROOT, 'my-shop.json');

// 改一项配置就写回配置文件（控制台里改店铺名、自动扫描填活动都走这里）。
// 手写 JSON 不用 ConvertTo-Json 之类的工具：那类工具会带 BOM，Node 读回会直接报错。
export function saveConfigPatch(patch) {
  const path = configFilePath();
  let current = {};
  if (existsSync(path)) {
    try { current = JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, '')); } catch { current = {}; }
  }
  const next = { ...current, ...patch };
  writeFileSync(path, JSON.stringify(next, null, 2) + '\n', 'utf8');
  return path;
}

const override = readOverride();
const shopName = override.shopName === undefined
  ? DEFAULTS.shopName
  : (String(override.shopName).trim() || '我的店铺');
const sellerName = String(override.sellerName || '').trim();

// 路径容错：把工具包整个复制到另一台电脑 / 另一个用户名下时，my-shop.json 里存的
// 绝对路径会失效（例如别人的 C:/Users/chen.jie/...）。失效就退回本包内目录 ——
// 宁可数据换个位置，也不能让整个工具打不开（早期版本真踩过：归档直接 ENOENT）。
function resolveDir(value, fallback, label) {
  const raw = String(value || '').trim();
  if (!raw) return fallback;
  const parent = dirname(raw.replace(/[\\/]+$/, ''));
  if (parent && existsSync(parent)) return raw;
  console.warn(`[店铺配置] ${label} 指向的目录不存在：${raw}`);
  console.warn(`           已自动改用本包内的：${fallback}（想固定目录就改 my-shop.json）`);
  return fallback;
}

export const SHOP = {
  ...DEFAULTS,
  ...override,
  shopName,
  sellerName,
  dataDir: resolveDir(override.dataDir, DEFAULTS.dataDir, 'dataDir'),
  runsDir: resolveDir(override.runsDir, DEFAULTS.runsDir, 'runsDir'),
  downloadsDir: resolveDir(override.downloadsDir, DEFAULTS.downloadsDir, 'downloadsDir'),
  // 数组类字段不做浅合并，避免半份旧店铺活动混进新店铺。
  // 空数组是**有效值**，意思是「后台默认的全部活动」——不要回退成 DEFAULTS 里的固定几个。
  plpCampaigns: override.plpCampaigns ?? DEFAULTS.plpCampaigns,
  plgCampaigns: override.plgCampaigns ?? DEFAULTS.plgCampaigns,
  priorityCampaigns: Array.isArray(override.priorityCampaigns)
    ? normalizeCampaigns(override.priorityCampaigns)
    : readPriorityCampaigns(shopName, sellerName),
  // 优先促刊默认勾选：没配就走 plpCampaigns（空 = 后台默认全部）
  priorityDefaultCampaigns: override.priorityDefaultCampaigns ?? (override.plpCampaigns ?? DEFAULTS.plpCampaigns)
};

// 路径类统一导出，其余模块只引用这里
export const DATA_DIR = SHOP.dataDir;
export const PENDING_DIR = join(DATA_DIR, '90-待处理');
export const REPO_DIR = join(DATA_DIR, '看板源码/ebay-online-dashboard');
export const HTML_SOURCE = join(DATA_DIR, '看板源码/ebay-traffic-dashboard/ebay-traffic-dashboard.html');
export const RUNS_DIR = SHOP.runsDir;
export const DEFAULT_DOWNLOAD_DIR = SHOP.downloadsDir;
export const DASHBOARD_URL = SHOP.dashboardUrl;
export const PLP_CAMPAIGNS = SHOP.plpCampaigns;
export const PLG_CAMPAIGNS = SHOP.plgCampaigns;

// 优先促销刊登活动：快照缺省时退回 PLP 三个，保证控制台不会因为没跑探针而空白
const priorityList = SHOP.priorityCampaigns.length
  ? SHOP.priorityCampaigns
  : SHOP.plpCampaigns.map(id => ({ id, name: id }));
export const PRIORITY_CAMPAIGNS = priorityList.map(c => ({
  id: c.id,
  name: c.name || c.id,
  plp: SHOP.plpCampaigns.includes(c.id)
}));
export const PRIORITY_DEFAULT_IDS = SHOP.priorityDefaultCampaigns
  .filter(id => PRIORITY_CAMPAIGNS.some(c => c.id === id));

export const CONSOLE_PORT = SHOP.consolePort;
export const BRIDGE_PORT = SHOP.bridgePort;

// 启动体检：把生效配置打出来，迁移时一眼看出有没有读对文件
export function shopSummary() {
  return {
    shopName: SHOP.shopName,
    sellerName: SHOP.sellerName,
    configFile: configFilePath(),
    dataDir: DATA_DIR,
    runsDir: RUNS_DIR,
    dashboardUrl: DASHBOARD_URL,
    // 0 不是错：0 表示「后台默认全部活动」，控制台和下载侧都按全部处理
    plpCampaigns: PLP_CAMPAIGNS.length,
    plgCampaigns: PLG_CAMPAIGNS.length,
    priorityCampaigns: PRIORITY_CAMPAIGNS.length,
    priorityDefaultCampaigns: PRIORITY_DEFAULT_IDS.length,
    campaignsMode: (PLP_CAMPAIGNS.length || PLG_CAMPAIGNS.length) ? '指定活动' : '后台全部活动'
  };
}
