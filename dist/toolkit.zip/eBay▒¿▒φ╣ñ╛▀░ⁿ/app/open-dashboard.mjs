// 打开本地看板（双击「打开看板.cmd」时调用）。
// 做两件事：
//   1) 起一个只监听 127.0.0.1 的小服务（app/dashboard-server.mjs），让看板能把「数据」目录里的
//      CSV 自己拉进去 —— 运营不用再点「选择文件」。服务已经在跑就直接复用，不重复起。
//   2) 打开浏览器。服务起不来时退回 file:// 直接开文件（老用法：手动选 CSV）。
// .cmd 里不写中文路径，编码问题就不会出现。
import { existsSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const BOARD_DIR = join(ROOT, '看板');
const HTML = join(BOARD_DIR, 'ebay-shop-dashboard.html');
const PORT_FILE = join(BOARD_DIR, '服务端口.txt');
const SERVER = join(ROOT, 'app', 'dashboard-server.mjs');

if (!existsSync(HTML)) {
  console.error('[X] 找不到看板文件：' + HTML);
  console.error('    这个包不完整，请重新运行安装器（或用「检查更新.cmd」拉一次）。');
  process.exit(1);
}

const sleep = ms => new Promise(done => setTimeout(done, ms));

function openBrowser(target) {
  const child = spawn(process.env.COMSPEC || 'cmd.exe', ['/c', 'start', '', target], {
    detached: true, stdio: 'ignore', windowsHide: true
  });
  child.unref();
}

// 这个端口上是不是「我们这一份」的看板服务。
// 必须比对安装目录：同一台机器上装两份工具（或复制了一份包）时，端口会撞车，
// 用错别人的服务就会显示别人的数据。
const sameDir = (a, b) => Boolean(a) && Boolean(b) && a.replace(/[\\/]+$/, '').toLowerCase() === b.replace(/[\\/]+$/, '').toLowerCase();

async function health(port) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(1200) });
    if (!res.ok) return null;
    const body = await res.json();
    if (!body || body.app !== 'ebay-dashboard-server') return null;
    return sameDir(body.root, ROOT) ? body : null;
  } catch { return null; }
}

function savedPort() {
  try {
    const port = Number(readFileSync(PORT_FILE, 'utf8').trim());
    return port >= 1 && port <= 65535 ? port : 0;
  } catch { return 0; }
}

async function findRunning() {
  const candidates = [savedPort(), ...Array.from({ length: 30 }, (_, i) => 7801 + i)];
  for (const port of [...new Set(candidates.filter(Boolean))]) {
    const info = await health(port);
    if (info) return port;
  }
  return 0;
}

async function startServer() {
  if (!existsSync(SERVER)) return 0;
  // 直接在本进程里起服务，不再 spawn 子进程：少一层进程就少一种「父进程一退、服务就没了」的情况。
  // 这个进程随后会一直挂着（浏览器关掉后 90 分钟自己退），由 .cmd 用 start /min 最小化启动。
  import('./dashboard-server.mjs').catch(error => {
    console.error('[X] 看板服务起不来：' + (error && error.message ? error.message : error));
  });
  // 首次启动要扫一遍数据目录（算哈希去重），几十份 CSV 大概 1~3 秒
  for (let i = 0; i < 60; i++) {
    await sleep(300);
    const port = await findRunning();
    if (port) return port;
  }
  return 0;
}

const port = (await findRunning()) || (await startServer());

if (port) {
  // 顺带把「加载了几份、最新到哪天」说清楚，方便判断数据是不是已经下过
  try {
    const res = await fetch(`http://127.0.0.1:${port}/auto-data.json`, { signal: AbortSignal.timeout(20000) });
    const data = await res.json();
    if (data.count) {
      console.log(`看板已就绪：已自动加载 ${data.count} 份报表（${(data.totalBytes / 1048576).toFixed(1)} MB），不用手动选文件。`);
    } else {
      console.log('看板已就绪，但「数据」目录里还没有报表。');
      console.log('先双击「报表控制台.cmd」→ 点「自动下载最近 30 天」，跑完再回来打开看板。');
    }
  } catch { /* 打印不出来不影响打开 */ }
  openBrowser(`http://127.0.0.1:${port}/`);
} else {
  console.log('本机看板服务没起来（端口被占用或被安全软件拦了），改用直接打开文件的方式。');
  console.log('打开后点「选择文件」，把「数据\\90-待处理」里的 CSV 全选上传即可。');
  openBrowser(HTML);
}
