// 固定参数：轮询节奏、页面 URL、报表派生量。店铺 / 机器相关值全部来自 shop-config.mjs。
// 迁移到另一家店铺：改 app/shop-config.mjs，或设 EBAY_SHOP_CONFIG 指向外部 JSON，本文件不用动。
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { REPORTS, getReport } from './reports.mjs';
import {
  DATA_DIR, PENDING_DIR, REPO_DIR, HTML_SOURCE, RUNS_DIR,
  DEFAULT_DOWNLOAD_DIR, DASHBOARD_URL, PLP_CAMPAIGNS,
  PRIORITY_CAMPAIGNS, PRIORITY_DEFAULT_IDS,
  PLG_CAMPAIGNS as SHOP_PLG_CAMPAIGNS, BRIDGE_PORT
} from './shop-config.mjs';

export {
  DATA_DIR, PENDING_DIR, REPO_DIR, HTML_SOURCE, RUNS_DIR,
  DEFAULT_DOWNLOAD_DIR, DASHBOARD_URL, PRIORITY_CAMPAIGNS, PRIORITY_DEFAULT_IDS
};

export const ROOT = dirname(fileURLToPath(import.meta.url));
export const BRIDGE = `http://127.0.0.1:${BRIDGE_PORT}`;
// 指向守护进程：它会保证桥一直在线，桥崩了 3 秒内自动拉起，永不留下「没有桥」的状态
export const BRIDGE_SCRIPT = join(ROOT, 'bridge-daemon.mjs');

export const TRAFFIC_URL = 'https://www.ebay.com/sh/performance/traffic';
export const REPORTS_URL = 'https://www.ebay.com/sh/reports/downloads';
export const CAMPAIGN_URL = id => `https://www.ebay.com/sh/ads/dashboard/campaign/${id}`;

// PLP campaign（链接 / 关键词 / 搜索词各 1 份）：来自店铺配置
export const CAMPAIGNS = PLP_CAMPAIGNS;

// PLP 异步生成：静等 120 秒后首检，之后每 30 秒查一次（查太勤会打断它自己的生成队列）
export const PLP_POLL = {
  firstWaitMs: 120000,    // 首次提交后先静等 120 秒：生成本来就慢，查太勤会打断它自己的队列
  retryWaitMs: 60000,     // 点 Try again 重新提交后静等 60 秒（重试时队列较短），再开始查
  intervalMs: 30000,      // 刷新间隔上限：每 30 秒最多刷新一次页面
  settleMs: 12000,        // 刷新后最多等 12 秒看按钮出现（实测 eBay 渲染就绪态要 6~8 秒，2.5 秒必漏）
  settlePollMs: 500,      // 刷新后读 DOM 的间隔
  watchMs: 2000,          // 两次刷新之间只读 DOM 的轻查间隔（不刷新、无网络请求）
  timeoutMs: 300000,
  downloadTimeoutMs: 60000
};

// 报表中心（PLG / 在售名单）异步生成：3 秒轮询，最多 90 秒
export const RC_POLL = {
  intervalMs: 2000,
  timeoutMs: 130000,        // 实测 31 个活动 + 每日，生成约 50 秒；留足余量
  reloadSettleMs: 2200,
  // 2026-11-08 实测：报表中心列表不再自动刷新（提交后两分钟纹丝不动），
  // 必须自己软刷新才能看到新行；间隔太密会打断渲染，25 秒比较稳。
  refreshEveryMs: 25000
};

// 快速报表（Traffic 等）页面等待与下载超时
export const FAST = {
  pageTimeoutMs: 45000,
  pagePollMs: 350,
  downloadTimeoutMs: 60000,
  filePollMs: 250
};

export const FOLDERS = {
  trafficDaily: '01-Traffic单日',
  trafficRange: '02-Traffic累计',
  plg: '03-PLG链接广告',
  plpListing: '04-PLP链接广告',
  plpKeyword: '05-PLP关键词',
  plpSearch: '06-PLP搜索词',
  active: '07-在售商品名单',
  activeUnsold: '08-非在售名单',
  activeScheduled: '09-预定名单',
  orders: '10-订单报表',
  priority: '11-优先促刊',
  pending: '99-待核验',
  inbox: '_inbox'
};

// 广告（常规促销刊登）下的活动：报表中心 Campaigns 卡片里可逐个勾选。来自店铺配置。
export const PLG_CAMPAIGNS = SHOP_PLG_CAMPAIGNS;

// 报表中心 Date range 卡片的全部取值（广告与订单通用）
export const RC_RANGES = [
  { value: 'TODAY', label: '今天' },
  { value: 'YESTERDAY', label: '昨天' },
  { value: 'CURRENTWEEK', label: '本周' },
  { value: 'LASTWEEK', label: '上周' },
  { value: 'CURRENTMONTH', label: '本月' },
  { value: 'PREVIOUSMONTH', label: '上月' },
  { value: 'LAST90D', label: '过去 90 天' },
  { value: 'CUSTOM', label: '自定义范围' }
];

// ---------- 以下三种报表类型都从 reports.mjs 派生，不再各写一份 ----------
const byId = id => {
  const r = getReport(id);
  if (!r) throw new Error(`报表注册表缺少 ${id}`);
  return r;
};

const listingReports = REPORTS.filter(r => r.group === 'listings');
const orderReports = REPORTS.filter(r => r.group === 'orders');
// 按报表中心 Type 卡片里的实际顺序排列，页面上的选项顺序与后台一致
const PRIORITY_ORDER = ['KEYWORD', 'LISTING', 'CAMPAIGN', 'SEARCH_QUERY'];
const priorityReports = REPORTS
  .filter(r => r.strategy === 'PL_P')
  .sort((a, b) => PRIORITY_ORDER.indexOf(a.type) - PRIORITY_ORDER.indexOf(b.type));

// 在售 / 非在售 / 预定：键名沿用原来的 active / unsold / scheduled
export const ACTIVE_TYPES = Object.fromEntries(listingReports.map(r => [r.key, {
  type: r.type,
  label: r.label,
  folder: r.folder,
  rowMatch: new RegExp(r.rowMatch, 'i'),
  fileStem: r.fileStem,
  reportId: r.id
}]));

// 订单报表 9 种
export const ORDER_TYPES = orderReports.map(r => ({
  key: r.id.split('.').pop(),
  label: r.label,
  type: r.type,
  reportId: r.id,
  rowMatch: new RegExp(r.rowMatch, 'i'),
  rowName: r.rowName,
  mvp: r.implemented !== false
}));

// 优先促销刊登 4 种
// 关键词 / 搜索词默认不下载（2026-11-10 定）：看板上这两个板块可以留空，
// 需要时在控制台把 chip 勾上单独下一次。Listing 与活动汇总是默认要的。
const PRIORITY_DEFAULT_OFF = new Set(['KEYWORD', 'SEARCH_QUERY']);
export const PRIORITY_TYPES = priorityReports.map(r => ({
  key: r.id.split('.').pop(),
  label: r.label,
  type: r.type,
  hasCampaigns: r.hasCampaigns,
  reportId: r.id,
  mvp: r.implemented !== false,
  defaultOn: !PRIORITY_DEFAULT_OFF.has(r.type)
}));

// 报表中心：按卡片顺序逐级选择（Source → 策略/类型 → 活动 → 粒度 → 区间）
function stepsOf(r) {
  const steps = [{ card: 'Source', fragment: `"SOURCE":"${r.sourceId}"` }];
  if (r.strategy) steps.push({ card: 'Campaign strategy', fragment: `"CAMPAIGN_TYPE":"${r.strategy}"` });
  if (r.type) steps.push({ card: 'Type', fragment: `"TYPE":"${r.type}"` });
  if (r.hasCampaigns) steps.push({ card: 'Campaigns' });   // 只在选部分活动时才操作，默认保持全选
  if (r.timeUnit) steps.push({ card: 'Time unit', fragment: '"CAMPAIGN_TIME_UNIT":"DAILY"' });
  if (r.rangeKind === 'orders') steps.push({ card: 'Date range', fragment: '"DATE_RANGE":"LAST90D"' });
  else if (r.rangeKind === 'marketing') steps.push({ card: 'Date range', fragment: '"DATE_RANGE":"CURRENTWEEK"' });
  return steps;
}

const requestOf = id => {
  const r = byId(id);
  return { label: r.label, rowMatch: new RegExp(r.rowMatch, 'i'), steps: stepsOf(r), reportId: r.id };
};

export const RC_REQUESTS = {
  plg: requestOf('marketing.plg.listing'),
  active: requestOf('listings.active'),
  orders: requestOf('orders.all'),
  priority: requestOf('marketing.priority.keyword')
};

// 订单报表的日期范围比广告多「今年/去年」
export const ORDER_RANGES = [
  ...RC_RANGES.slice(0, 6),
  { value: 'CURRENTYEAR', label: '今年' },
  { value: 'PREVIOUSYEAR', label: '去年' },
  ...RC_RANGES.slice(6)
];

// 优先促销刊登、报表中心请求结构已在上面由 reports.mjs 派生

export function yesterdayPacific(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);
  const pick = type => parts.find(part => part.type === type)?.value;
  const today = `${pick('year')}-${pick('month')}-${pick('day')}`;
  const date = new Date(`${today}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() - 1);
  return date.toISOString().slice(0, 10);
}

export function monthStart(isoDate) {
  return `${isoDate.slice(0, 7)}-01`;
}

export function toUsDate(isoDate) {
  const [y, m, d] = isoDate.split('-');
  return `${m}/${d}/${y}`;
}

export function toUsPeriodStart(isoDate) {
  const [y, m, d] = isoDate.split('-');
  return `${m}/${d}/${y}`;
}
