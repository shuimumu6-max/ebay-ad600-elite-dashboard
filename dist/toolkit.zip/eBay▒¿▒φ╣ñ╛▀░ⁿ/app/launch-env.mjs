// 环境启动器：确保「常驻桥」在线。
// 正常情况（浏览器没重启过）这一步完全不需要你动手；
// 只有浏览器重启后，调试开关会回到关闭状态，这时会帮你把开关页面打开，你拨一次即可。
import { appendFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ensureEnv, bridgeHealth, findChrome, sleep } from './ensure-env.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const LOG = join(here, 'launch.log');

try { writeFileSync(LOG, ''); } catch { /* 忽略 */ }
const log = text => {
  console.log(text);
  try { appendFileSync(LOG, text + '\n'); } catch { /* 忽略 */ }
};

log('============================================');
log(' eBay 报表下载环境');
log('============================================');
log('');

if (!findChrome()) {
  log('[X] 没找到 Google Chrome，请确认安装后重试。');
  process.exit(1);
}

const before = await bridgeHealth();
if (before?.connected) {
  log('[OK] 常驻连接已在线，什么都不用做。');
  log('     连接一直保持，期间所有下载都不会再问你要授权。');
  log('');
  log(' 环境已就绪。直接双击「报表控制台.cmd」或「一键下载.cmd」即可。');
  process.exit(0);
}

log('[1/2] 启动常驻连接服务…');
const result = await ensureEnv({
  onLog: text => log('      ' + text),
  openInspect: true,
  waitAuthMs: 300000
});

if (result.ok) {
  log('[2/2] 连接已就绪。');
  log('');
  log(' 环境已就绪，用的是你平时那个已登录的 Chrome，不需要重新登录。');
  log(' 这一条连接会一直保持：之后下载、重启控制台、关窗口都不会再问你要授权。');
  log(' 只有「你关闭或重启了 Chrome」时，才需要再来一次。');
  log('');
  process.exit(0);
}

log('');
log('[X] 环境还没就绪：' + (result.reason || '浏览器调试开关未打开'));
log('');
log(' 需要你做的只有一件事：');
log('   1) 在 Chrome 里打开新标签页，地址栏输入  chrome://inspect/#remote-debugging');
log('   2) 勾选「Allow remote debugging for this browser instance」（允许对此浏览器实例进行远程调试）');
log('   3) 拨开后回来，双击「报表控制台.cmd」即可，不用再点任何允许');
log('');
log(' 说明：这个开关是 Chrome 的安全设计，浏览器每次重启后都会自动关闭，');
log('       所以每次重启浏览器后需要拨一次；浏览器不重启就一直有效。');
log(` 日志：${LOG}`);
process.exit(1);
