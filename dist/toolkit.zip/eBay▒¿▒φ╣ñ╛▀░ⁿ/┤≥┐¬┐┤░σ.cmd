@echo off
chcp 65001 >nul
start "" "%~dp0看板\ebay-shop-dashboard.html"
