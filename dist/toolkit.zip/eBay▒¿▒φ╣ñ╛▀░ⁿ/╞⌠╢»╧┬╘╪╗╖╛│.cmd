@echo off
chcp 65001 >nul
"%~dp0bin\node.exe" "%~dp0app\launch-env.mjs"
echo.
pause
