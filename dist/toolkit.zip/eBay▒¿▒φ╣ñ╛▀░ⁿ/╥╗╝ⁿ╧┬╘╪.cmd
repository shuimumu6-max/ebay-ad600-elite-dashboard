@echo off
chcp 65001 >nul
"%~dp0bin\node.exe" "%~dp0app\quick-download.mjs" %*
echo.
pause
