// 常驻 CDP 桥：整个系统只在浏览器重新启动后需要授权一次。
// 桥自己永不退出、永不主动断开，连着的时候每 20 秒发一次心跳，
// 让 Chrome 认为调试会话一直活跃，不会因为闲置把调试开关关掉。
// 所有脚本都通过 http://127.0.0.1:<桥端口> 转发，不再各自新建 9222 连接，也就不会重复弹授权。
//
// 2026-11-14 多店铺隔离：桥端口不能再写死 9233 —— 每店在 local.json 里有独立 bridgePort
// （9300/9310/…），下载侧按店连的是自己那个端口。桥必须监听同一个端口、并只读本店实例的
// DevToolsActivePort，否则多店下载连不上桥（或用错店的浏览器）。
import { createServer } from 'node:http';
import { Socket } from 'node:net';
import { appendFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = dirname(root);
const SHOP_ID = String(process.env.EBAY_SHOP_ID || '').trim();

// 按店解析机器状态（与 app/shop-config.mjs 的 L3 读取规则一致，但不依赖它，
// 保持桥可以独立启动、且不受下载侧单例影响）：
//   EBAY_BRIDGE_PORT 显式覆盖 > local.json 的 shops/<id>.bridgePort > 默认 9233。
function readLocal() {
  try {
    const f = join(PROJECT_ROOT, 'local.json');
    if (!existsSync(f)) return {};
    return JSON.parse(readFileSync(f, 'utf8').replace(/^\uFEFF/, ''));
  } catch { return {}; }
}
const local = readLocal();
const shopLocal = SHOP_ID && local.shops ? (local.shops[SHOP_ID] || {}) : {};
const PORT = Number(process.env.EBAY_BRIDGE_PORT || shopLocal.bridgePort || 9233);
// 0 = 不兜底。9222 是历史上给「手动 --remote-debugging-port=9222」的旧 Chrome 留的，
// 但那个端口也常被别的工具占用，连过去会「界面显示已连接、下载却不是这个浏览器」，
// 比连不上更难查。默认只认 Chrome 自己写的 DevToolsActivePort。
const FALLBACK_PORT = Number(process.env.EBAY_FALLBACK_CDP_PORT || 0);
// 下载目录按店派生，别让 A 店的浏览器下载落进 B 店目录（单店仍落 app/downloads）。
const DOWNLOAD_DIR = SHOP_ID
  ? join(PROJECT_ROOT, '店铺', SHOP_ID, 'downloads')
  : join(root, 'downloads');
// 日志按店分开，多店同时排障时不会互相覆盖。
const logFile = join(root, SHOP_ID ? `bridge-${SHOP_ID}.log` : 'bridge.log');

// 只保留最近的日志，避免文件无限增长（长期常驻）
const LOG_MAX_BYTES = 1024 * 1024;

// Chrome 144+ 的原地调试服务不暴露 /json/*，WS 地址有三种可靠来源，按新→旧依次尝试：
//   1) 本店独立实例的 endpoint.json（launch-shop.mjs 从 stderr 解析后写入，最准）；
//   2) app/launch-<shop>.log 的最后一条 "DevTools listening on ws://…"（endpoint 未写入时的兜底）；
//   3) 实例目录的 DevToolsActivePort（Chrome 157 实测不写这个文件，仅作老版本兼容）；
//   4) /json/version 的 webSocketDebuggerUrl（新实例首次启动、上面三处都还没落盘时）。
// 2026-11-14 实测：Chrome 157 只把 WS 地址打到 stderr，不写 DevToolsActivePort，
// 只认端口文件会让桥永远连不上独立实例 → 多店下载链路直接断。
// 只认"用户自己的日常 Chrome"（2026-11-18 实测）：克隆到独立 user-data-dir 起新实例，
// 会被 eBay 当"新设备" → captcha → 卖家页要重登 → 下不了。
// 多店靠"日常 Chrome 里的不同 Profile"（各自登录），不再用 local.json 的 shops/<id>.userDataDir。
const USER_DATA_DIRS = [
  process.env.CDP_USER_DATA_DIR,
  process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'User Data') : null,
  process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'Google', 'Chrome Beta', 'User Data') : null,
].filter(Boolean);

// 端点候选：只从"日常 Chrome 的 user-data-dir"读 DevToolsActivePort（原地调试）。
// 不再使用 endpoint.json / launch-<shop>.log / 独立 cdpPort 这些"克隆实例"来源。
function listCdpCandidates() {
  const found = [];
  for (const dir of USER_DATA_DIRS) {
    const file = join(dir, 'DevToolsActivePort');
    if (!existsSync(file)) continue;
    try {
      const lines = readFileSync(file, 'utf8').trim().split(/\r?\n/).map(line => line.trim()).filter(Boolean);
      const port = Number(lines[0]);
      if (!Number.isFinite(port) || port <= 0) continue;
      const wsPath = lines[1] && lines[1].startsWith('/') ? lines[1] : '/devtools/browser';
      found.push({ url: `ws://127.0.0.1:${port}${wsPath}`, port, from: dir, mtime: statSync(file).mtimeMs });
    } catch { /* 继续找下一个 */ }
  }
  // 多个候选目录并存时，最新写入的更可能是当前活跃实例
  return found.sort((a, b) => b.mtime - a.mtime);
}

// 连接路径专用：同步来源探一次 TCP 即可（只连日常 Chrome，无 HTTP 兜底）。
// 用户自己的 Chrome 用"原地调试"，DevToolsActivePort 一直在。
async function resolveLiveEndpoint() {
  const list = listCdpCandidates();
  for (const item of list) {
    if (await portOpen(item.port)) return { ...item, ageMs: Date.now() - item.mtime };
  }
  if (!FALLBACK_PORT) return { url: null, port: 0, from: 'none', ageMs: null, mtime: 0 };
  return { url: `ws://127.0.0.1:${FALLBACK_PORT}/devtools/browser`, port: FALLBACK_PORT, from: 'fallback', ageMs: null, mtime: 0 };
}

// 同步来源：endpoint.json / launch 日志 / DevToolsActivePort。
// /health 与「端口刚就绪」轻量轮询都走这里（不能再走网络 I/O）。
function resolveCdpUrl() {
  const list = listCdpCandidates();
  if (list.length) return { ...list[0], ageMs: Date.now() - list[0].mtime };
  if (!FALLBACK_PORT) return { url: null, port: 0, from: 'none', ageMs: null, mtime: 0 };
  return { url: `ws://127.0.0.1:${FALLBACK_PORT}/devtools/browser`, port: FALLBACK_PORT, from: 'fallback', ageMs: null, mtime: 0 };
}

// 端口文件可能残留（浏览器关掉后文件还在），必须真正探一次 TCP 才算数
function portOpen(port, timeoutMs = 400) {
  return new Promise(resolve => {
    const sock = new Socket();
    let done = false;
    const finish = ok => { if (done) return; done = true; sock.destroy(); resolve(ok); };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => finish(true));
    sock.once('timeout', () => finish(false));
    sock.once('error', () => finish(false));
    sock.connect(port, '127.0.0.1');
  });
}

const log = text => {
  const line = `${new Date().toISOString()} ${text}`;
  console.log(line);
  try {
    if (existsSync(logFile) && statSync(logFile).size > LOG_MAX_BYTES) {
      // 简单轮转：超限就清空重写，长期常驻也不会把磁盘写满
      writeFileSync(logFile, '');
    }
    appendFileSync(logFile, line + '\n');
  } catch { /* 日志失败不影响服务 */ }
};

let seq = 0;
let socket = null;
let connected = false;
let everConnected = false;
let lastConnectedAt = 0;
let lastClosedAt = 0;
let reconnectTries = 0;
let reconnectTimer = null;
let waitingAuth = false;     // 已发起连接但还没握手成功（Chrome 正在等用户点允许）
let lastAttemptAt = 0;
let lastLogAt = 0;
const pending = new Map();
const events = [];
let trafficSession = null;
let trafficTargetId = null;

function send(method, params = {}, sessionId) {
  if (!connected || !socket) throw new Error('浏览器调试未连接（需要点一次允许）');
  return new Promise((resolve, reject) => {
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' 超时（30 秒）')); }, 30000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}

function onMessage(event) {
  let data;
  try { data = JSON.parse(String(event.data)); } catch { return; }
  const task = pending.get(data.id);
  if (task) {
    clearTimeout(task.timer);
    pending.delete(data.id);
    if (data.error) task.reject(new Error(JSON.stringify(data.error)));
    else task.resolve(data.result);
    return;
  }
  if (data.method === 'Browser.downloadWillBegin' || data.method === 'Browser.downloadProgress') {
    events.push({ at: Date.now(), method: data.method, params: data.params });
    if (events.length > 60) events.shift();
    if (data.method === 'Browser.downloadProgress' && data.params.state === 'completed') log('检测到报表下载完成。');
  }
}

function scheduleReconnect(delayMs) {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(() => { reconnectTimer = null; attemptConnect().catch(() => {}); }, delayMs);
}

// 建立一次连接。成功就长期保持；失败按退避重试，永不退出进程。
async function attemptConnect() {
  if (connected || waitingAuth) return;
  if (socket) { try { socket.__manual = true; socket.close(); } catch { /* 忽略 */ } socket = null; }

  const endpoint = await resolveLiveEndpoint();
  lastAttemptAt = Date.now();
  const quiet = reconnectTries >= 6; // 长时间连不上时降噪，避免日志刷屏

  // 找不到调试端口文件 = Chrome 的开关没拨（或浏览器没开）。这时候建 WS 没意义，
  // 保留 waitingAuth=false，界面才会给出「需要拨一次开关」而不是「等你点允许」。
  if (!endpoint.url) {
    waitingAuth = false;
    reconnectTries += 1;
    if (!quiet) log('没找到浏览器调试端口：Chrome 的 Allow remote debugging 还没拨开。10 秒后再看一次。');
    scheduleReconnect(10000);
    return;
  }

  if (!quiet) log(`正在连接浏览器调试：${endpoint.url}（来源 ${endpoint.from}）`);
  waitingAuth = true;

  const ws = new WebSocket(endpoint.url);
  socket = ws;
  let settled = false;

  // 握手超时：Chrome 会把「等你点允许」的连接挂住，既不 open 也不 error。
  // 没有超时的话桥就永久停在 waiting-auth，连重试都不会发生 ——
  // 用户看到的就是「一直在重连，点了也没反应」。超时后主动放弃这条连接，交给退避重试。
  const openTimer = setTimeout(() => {
    if (settled) return;
    settled = true;
    waitingAuth = false;
    try { ws.__manual = true; ws.close(); } catch { /* 忽略 */ }
    socket = null;
    reconnectTries += 1;
    log('连接浏览器超时（Chrome 多半在等你点「允许」）。稍后自动重试，也可以打开 chrome://inspect/#remote-debugging 点一次允许。');
    scheduleReconnect(10000);
  }, 25000);

  ws.addEventListener('message', onMessage);

  ws.addEventListener('open', () => {
    settled = true;
    clearTimeout(openTimer);
    connected = true;
    everConnected = true;
    waitingAuth = false;
    reconnectTries = 0;
    lastConnectedAt = Date.now();
    log('浏览器调试已连接。此后所有任务走本地常驻桥，不会再要求点允许。');
    setupSession();
  });

  ws.addEventListener('error', () => {
    // 端口没开 / 开关已关闭，都会走到这里
    if (settled) return;
    settled = true;
    clearTimeout(openTimer);
    ws.__manual = true;   // 紧随其后的 close 事件不必再排一次重连，避免重连计数翻倍
    waitingAuth = false;
    connected = false;
    socket = null;
    reconnectTries += 1;
    // 端口开着却握手失败：多半是用户正在拨开关，几秒内就可能变成可用。
    // 这时候按 60 秒退避会让用户「拨完还要干等一分钟」，所以固定 8 秒重试。
    // 端口关着（开关还没拨）才用长退避，避免空转。
    portOpen(endpoint.port).then(up => {
      const backoff = up ? 8000 : [5000, 5000, 10000, 20000, 30000, 60000][Math.min(reconnectTries - 1, 5)];
      const now = Date.now();
      if (!quiet || now - lastLogAt > 120000 || up) {
        lastLogAt = now;
        log(up
          ? `第 ${reconnectTries} 次连接失败：端口是开的但 Chrome 没接受（授权没过）。${backoff / 1000} 秒后重试。`
          : `第 ${reconnectTries} 次连接失败：端口未开放（需要把远程调试开关打开）。${backoff / 1000} 秒后重试。`);
      }
      scheduleReconnect(backoff);
    });
  });

  ws.addEventListener('close', () => {
    // 主动替换旧连接时不要触发重连，否则会自我打架
    if (ws.__manual) return;
    const wasConnected = connected;
    connected = false;
    waitingAuth = false;
    trafficSession = null;
    trafficTargetId = null;
    for (const task of pending.values()) { clearTimeout(task.timer); task.reject(new Error('CDP 连接断开')); }
    pending.clear();
    lastClosedAt = Date.now();
    if (wasConnected) {
      log('调试连接断开（浏览器关闭或重启了）。会自动重试；浏览器重新打开并允许一次调试即可恢复。');
      reconnectTries = 1;
      scheduleReconnect(3000);
    } else {
      // 首次连接时用户直接关掉了浏览器：也要继续重试，不能就此卡住
      reconnectTries += 1;
      scheduleReconnect(8000);
    }
  });
}

async function setupSession() {
  try {
    mkdirSync(DOWNLOAD_DIR, { recursive: true });
    await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: DOWNLOAD_DIR, eventsEnabled: true });
    log(`下载目录已设为 ${DOWNLOAD_DIR}`);
  } catch (error) { log('设置下载目录失败：' + error.message); }
}

async function ensureTrafficSession(pathMatch) {
  const { targetInfos } = await send('Target.getTargets');
  const target = targetInfos.find(item => {
    if (item.type !== 'page') return false;
    try {
      const url = new URL(item.url);
      return /^(www\.)?ebay\.com$/.test(url.hostname) && (pathMatch ? url.pathname.includes(pathMatch) : url.pathname === '/sh/performance/traffic');
    } catch { return false; }
  });
  if (!target) throw new Error('未找到 eBay Traffic 标签页，请先打开该页面。');
  if (trafficSession && trafficTargetId === target.targetId) return trafficSession;
  const { sessionId } = await send('Target.attachToTarget', { targetId: target.targetId, flatten: true });
  trafficSession = sessionId;
  trafficTargetId = target.targetId;
  return sessionId;
}

const readBody = req => new Promise((resolve, reject) => {
  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', () => {
    try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
    catch (error) { reject(new Error('请求体不是有效 JSON：' + error.message)); }
  });
  req.on('error', reject);
});

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const reply = (code, obj) => {
    res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify(obj));
  };
  try {
    if (url.pathname === '/health') {
      const endpoint = resolveCdpUrl();
      // 「端口根本没开」和「端口开着但 Chrome 没接受这次连接」是两种完全不同的处境：
      // 前者要让用户去拨开关，后者开关已经开了、要让他把开关关掉再拨一次（或点「允许」）。
      // 混成一句「端口未开放」会让用户反复去拨一个本来就开着的开关，越弄越乱。
      const portUp = connected ? true : (endpoint.port ? await portOpen(endpoint.port) : false);
      return reply(200, {
        connected, everConnected, port: PORT, reconnectTries,
        // 以「调试端口到底开没开」为准，不要用 waitingAuth：
        // 它在握手开始前就被置 true，开关关着时也会误报「等你点允许」，
        // 用户明明没拨开关却被告知去点允许，越弄越乱。
        phase: connected ? 'connected' : (portUp ? 'waiting-auth' : 'reconnecting'),
        // needsAuth 的含义是「必须去浏览器里点一次才能连上」。waiting-auth 同样是在等
        // 用户点「允许」，不能算成"不需要操作"——否则界面只会显示「正在重连…」，
        // 连个按钮都没有，用户只能干等。
        needsAuth: !connected,
        awaitingApproval: !connected && portUp,
        pid: process.pid,
        uptimeSec: Math.round(process.uptime()),
        lastConnectedAt: lastConnectedAt || null,
        lastClosedAt: lastClosedAt || null,
        endpointPort: endpoint.port,
        endpointPortOpen: portUp,
        endpointFrom: endpoint.from,
        hint: connected
          ? null
          : portUp
            ? '调试端口是开的，但 Chrome 没接受这次连接：到 chrome://inspect/#remote-debugging 把开关关掉再拨开一次（或在弹出的提示里点「允许」）'
            : '浏览器调试开关是关的：打开 chrome://inspect/#remote-debugging，把 Allow remote debugging 拨到开',
        downloadDir: DOWNLOAD_DIR,
        lastEvent: events.at(-1) || null
      });
    }
    if (url.pathname === '/events') return reply(200, { events });
    if (url.pathname === '/reconnect' && req.method === 'POST') {
      reconnectTries = 0;
      scheduleReconnect(100);
      return reply(200, { ok: true });
    }
    if (url.pathname === '/targets') {
      const result = await send('Target.getTargets');
      return reply(200, { targets: result.targetInfos.map(t => ({ type: t.type, title: t.title, url: t.url })) });
    }
    if (url.pathname === '/cdp' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body.method) return reply(400, { error: '缺少 method' });
      const result = await send(body.method, body.params || {}, body.sessionId);
      return reply(200, { result });
    }
    if (url.pathname === '/eval' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body.expression) return reply(400, { error: '缺少 expression' });
      const sessionId = await ensureTrafficSession(body.path);
      const result = await send('Runtime.evaluate', {
        expression: body.expression, returnByValue: true, awaitPromise: true
      }, sessionId);
      if (result.exceptionDetails) {
        return reply(200, { ok: false, error: result.exceptionDetails.text + ' ' + (result.exceptionDetails.exception?.description || '') });
      }
      return reply(200, { ok: true, value: result.result.value });
    }
    return reply(404, { error: '未知接口' });
  } catch (error) {
    log('请求失败：' + error.message);
    return reply(500, { error: error.message });
  }
});

server.on('error', error => {
  if (error.code === 'EADDRINUSE') {
    // 已经有桥在跑，直接正常退出，让守护去等待，不要在这里死循环
    log(`端口 ${PORT} 已被占用（已有桥在运行），本进程退出。`);
    process.exit(0);
  }
  log('桥服务启动失败：' + error.message);
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  log(`本地常驻桥已启动：http://127.0.0.1:${PORT}/health（pid ${process.pid}${SHOP_ID ? `，店铺 ${SHOP_ID}` : ''}）`);
});

// 未连接时轻量盯着 DevToolsActivePort：用户在 Chrome 里把开关打开后，
// 这个文件会立刻被重写，桥能 3 秒内自动连上，不用等退避周期、也不用重启任何东西。
let lastEndpointSig = '';
setInterval(() => {
  if (connected || waitingAuth) return;
  const ep = resolveCdpUrl();
  const sig = `${ep.port}|${ep.mtime}`;
  if (sig === lastEndpointSig) return;
  lastEndpointSig = sig;
  // 用户一拨开关，Chrome 会立刻重写这个文件，mtime 变化即视为「端口刚就绪」
  // port 0 = 还没找到端口文件，别把「没有」当成「刚更新」，否则日志每 10 秒刷一句
  if (ep.from !== 'fallback' && ep.port && reconnectTries > 0) {
    log(`检测到调试端口文件更新（端口 ${ep.port}），立即重连。`);
    reconnectTries = 0;
    scheduleReconnect(50);
  }
}, 3000);

// 心跳保活：复用同一条连接，绝不新建 WebSocket。20 秒一次，让 Chrome 始终认为会话活跃。
let beat = 0;
setInterval(() => {
  if (!connected) return;
  beat += 1;
  // 每 3 次心跳顺带取一次 target 列表，比单纯的 getVersion 更像真实活动
  const method = beat % 3 === 0 ? 'Target.getTargets' : 'Browser.getVersion';
  send(method).catch(() => { /* 断线由 close 事件处理 */ });
}, 20000);

// 兜底：桥进程绝不能因为未捕获异常退出
process.on('unhandledRejection', error => log('未捕获拒绝（已忽略，桥继续运行）：' + (error?.message || error)));
process.on('uncaughtException', error => log('未捕获异常（已忽略，桥继续运行）：' + (error?.message || error)));

attemptConnect().catch(() => {});
